// Haversine distance in meters between two lat/lng pairs
export function distanceMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export interface GeoPosition { lat: number; lng: number; accuracy: number; }

const errMap: Record<number, string> = {
  1: "Location permission denied. Please allow GPS access for this site in your browser settings.",
  2: "Position unavailable. Make sure GPS / Location is turned ON on your device.",
  3: "Timed out trying to get GPS. Move to an open area and try again.",
};

function tryGet(opts: PositionOptions): Promise<GeoPosition> {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        accuracy: pos.coords.accuracy,
      }),
      (err) => reject(Object.assign(new Error(errMap[err.code] || err.message), { code: err.code })),
      opts,
    );
  });
}

// On mobile, high-accuracy GPS often times out indoors. We try high-accuracy first,
// then fall back to low-accuracy network position so seminars indoors still work.
export async function getCurrentPosition(timeoutMs = 15000): Promise<GeoPosition> {
  if (!("geolocation" in navigator)) {
    throw new Error("This device does not support GPS / geolocation.");
  }
  try {
    return await tryGet({ enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 0 });
  } catch (e: any) {
    // Permission denied → don't retry
    if (e.code === 1) throw e;
    // Retry with lower accuracy and cached fix allowed
    return await tryGet({ enableHighAccuracy: false, timeout: timeoutMs, maximumAge: 60000 });
  }
}
