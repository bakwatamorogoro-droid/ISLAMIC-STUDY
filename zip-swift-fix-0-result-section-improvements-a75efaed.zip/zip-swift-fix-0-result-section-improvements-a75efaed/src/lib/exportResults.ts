import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export interface ResultRow {
  full_name: string;
  exam_number: string;
  score: number | null;
  total_marks: number | null;
  status: string;
  submitted_at: string | null;
  violation_reason: string | null;
}

const fmtDate = (s: string | null) => (s ? new Date(s).toLocaleString() : "—");
const pct = (s: number | null, t: number | null) =>
  t && t > 0 ? `${Math.round(((s || 0) / t) * 100)}%` : "—";

export function exportRowsToCSV(filename: string, headers: string[], rows: (string | number)[][]) {
  const esc = (v: any) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = [headers.map(esc).join(","), ...rows.map((r) => r.map(esc).join(","))].join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export function exportResultsToExcel(examTitle: string, rows: ResultRow[]) {
  const data = rows.map((r, i) => ({
    "#": i + 1,
    "Jina Kamili": r.full_name,
    "Namba ya Mtihani": r.exam_number,
    "Alama": r.score ?? 0,
    "Jumla": r.total_marks ?? 0,
    "Asilimia": pct(r.score, r.total_marks),
    "Hali": r.status.replace("_", " "),
    "Muda wa Kuwasilisha": fmtDate(r.submitted_at),
    "Maelezo ya Ukiukaji": r.violation_reason || "",
  }));
  const ws = XLSX.utils.json_to_sheet(data);
  ws["!cols"] = [
    { wch: 4 }, { wch: 28 }, { wch: 22 }, { wch: 8 }, { wch: 8 },
    { wch: 10 }, { wch: 16 }, { wch: 22 }, { wch: 30 },
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Matokeo");
  XLSX.writeFile(wb, `ISLAMIC_STUDIES_MUM_${examTitle.replace(/\s+/g, "_")}_Matokeo.xlsx`);
}

export function exportResultsToPDF(examTitle: string, rows: ResultRow[]) {
  const doc = new jsPDF({ orientation: "landscape" });
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("ISLAMIC STUDIES MUM", 14, 15);
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.text(`Mtihani: ${examTitle}`, 14, 22);
  doc.text(`Tarehe: ${new Date().toLocaleString()}`, 14, 28);
  doc.text(`Jumla ya Wanafunzi: ${rows.length}`, 14, 34);

  autoTable(doc, {
    startY: 40,
    head: [["#", "Jina", "Namba", "Alama", "Asilimia", "Hali", "Muda", "Maelezo"]],
    body: rows.map((r, i) => [
      i + 1,
      r.full_name,
      r.exam_number,
      `${r.score ?? 0}/${r.total_marks ?? 0}`,
      pct(r.score, r.total_marks),
      r.status.replace("_", " "),
      fmtDate(r.submitted_at),
      r.violation_reason || "",
    ]),
    styles: { fontSize: 9, cellPadding: 2 },
    headStyles: { fillColor: [15, 35, 70], textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [245, 247, 250] },
  });

  doc.save(`ISLAMIC_STUDIES_MUM_${examTitle.replace(/\s+/g, "_")}_Matokeo.pdf`);
}
