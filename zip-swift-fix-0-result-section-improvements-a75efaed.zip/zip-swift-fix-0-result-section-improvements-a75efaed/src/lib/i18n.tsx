import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type Lang = "sw" | "en";

type Dict = Record<string, { sw: string; en: string }>;

const dict: Dict = {
  brand: { sw: "ISLAMIC STUDIES MUM", en: "ISLAMIC STUDIES MUM" },
  brand_sub: { sw: "Islamic Studies Online Test", en: "Islamic Studies Online Test" },
  nav_results: { sw: "Matokeo", en: "Results" },
  nav_signup: { sw: "Jisajili Semina", en: "Register Seminar" },
  nav_exam: { sw: "Fanya Mtihani", en: "Take Exam" },
  hero_badge: { sw: "Mfumo Salama wa Mitihani", en: "Secure Examination Platform" },
  hero_title_1: { sw: "Fanya mtihani kwa", en: "Take exams with" },
  hero_title_2: { sw: "uhakika", en: "confidence" },
  hero_title_3: { sw: ", pasipo udanganyifu.", en: ", without cheating." },
  hero_no_exam: { sw: "Hakuna mtihani uliopangwa kwa sasa. Subiri tangazo kutoka kwa admin.", en: "No exam scheduled. Wait for an announcement from admin." },
  upcoming_exam: { sw: "Mtihani Ujao", en: "Upcoming Exam" },
  announcements: { sw: "Matangazo", en: "Announcements" },
  features_title: { sw: "Vipengele vya Usalama", en: "Security Features" },
  features_sub: { sw: "Kila kipengele kimeundwa kuzuia udanganyifu na kuhakikisha haki.", en: "Every feature is built to prevent cheating and ensure fairness." },
  how_title: { sw: "Jinsi Mfumo Unavyojilinda", en: "How the System Protects Itself" },
  cta_title: { sw: "Uko tayari kuanza?", en: "Ready to start?" },
  cta_sub: { sw: "Jisajili kwenye semina kwanza, kisha tumia Reg No yako (mfano: MUM2021-04-08738) wakati wa mtihani.", en: "Register for the seminar first, then use your Reg No (e.g. MUM2021-04-08738) during the exam." },
  footer_admin: { sw: "Usimamizi", en: "Management" },
  language: { sw: "Lugha", en: "Language" },

  // Common
  back: { sw: "Rudi", en: "Back" },
  cancel: { sw: "Ghairi", en: "Cancel" },
  save: { sw: "Hifadhi", en: "Save" },
  update: { sw: "Sasisha", en: "Update" },
  add: { sw: "Ongeza", en: "Add" },
  delete: { sw: "Futa", en: "Delete" },
  edit: { sw: "Hariri", en: "Edit" },
  loading: { sw: "Inapakia...", en: "Loading..." },
  open: { sw: "Fungua", en: "Open" },
  view: { sw: "Tazama", en: "View" },
  download: { sw: "Pakua", en: "Download" },
  upload: { sw: "Pakia", en: "Upload" },
  uploading: { sw: "Inapakia...", en: "Uploading..." },
  remove: { sw: "Ondoa", en: "Remove" },
  active: { sw: "Active", en: "Active" },
  inactive: { sw: "Inactive", en: "Inactive" },
  optional: { sw: "(hiari)", en: "(optional)" },

  // Groups / Seminar
  groups: { sw: "Magroup", en: "Groups" },
  group: { sw: "Group", en: "Group" },
  group_title: { sw: "Kichwa cha Group (hiari)", en: "Group title (optional)" },
  group_marks: { sw: "Marks za Group", en: "Group marks" },
  max: { sw: "Max", en: "Max" },
  student_limit: { sw: "Limit ya Wanafunzi", en: "Student limit" },
  group_full: { sw: "Group imejaa", en: "Group is full" },
  students_word: { sw: "wanafunzi", en: "students" },
  add_group: { sw: "Ongeza Group", en: "Add Group" },
  edit_group: { sw: "Hariri Group", en: "Edit Group" },
  members_link: { sw: "Wanafunzi", en: "Members" },
  export_excel: { sw: "Export Excel", en: "Export Excel" },
  semesters: { sw: "Semina", en: "Seminars" },
  no_groups_yet: { sw: "Hakuna group bado.", en: "No groups yet." },
  used_already: { sw: "imetumika", en: "used" },

  // GPS
  gps_required_toggle: { sw: "Hitaji GPS wakati wa kujisajili kwenye group hii", en: "Require GPS during signup for this group" },
  latitude: { sw: "Latitude", en: "Latitude" },
  longitude: { sw: "Longitude", en: "Longitude" },
  radius_m: { sw: "Radius (mita)", en: "Radius (meters)" },
  use_my_location: { sw: "Tumia eneo langu", en: "Use my location" },
  picking: { sw: "Inapata...", en: "Locating..." },

  // Student signup
  signup_seminar: { sw: "Jisajili kwa Semina", en: "Register for Seminar" },
  signup_sub: { sw: "Chagua semester na group, kisha jaza taarifa zako.", en: "Choose semester and group, then fill in your details." },
  semester: { sw: "Semester", en: "Semester" },
  full_name: { sw: "Jina kamili", en: "Full name" },
  reg_no: { sw: "Reg No", en: "Reg No" },
  gender: { sw: "Jinsia", en: "Gender" },
  course_studying: { sw: "Kozi unayosoma", en: "Course you study" },
  mobile_optional: { sw: "Mobile No (hiari)", en: "Mobile No (optional)" },
  choose_dash: { sw: "-- Chagua --", en: "-- Choose --" },
  signing_up: { sw: "Inasajili...", en: "Registering..." },
  signup_btn: { sw: "Jisajili", en: "Register" },
  group_full_msg: { sw: "Group hii imejaa. Tafadhali chagua group nyingine.", en: "This group is full. Please choose another group." },
  done_title: { sw: "Umejisajili Kikamilifu!", en: "You are registered!" },
  done_sub: { sw: "Umewekwa kwenye semina. Wakati wa mtihani utafika, ingia kwa kutumia Reg No yako tu.", en: "You have been added to the seminar. When the exam time comes, log in with your Reg No only." },
  home: { sw: "Nyumbani", en: "Home" },
  take_exam: { sw: "Fanya Mtihani", en: "Take Exam" },
  back_home: { sw: "Rudi nyumbani", en: "Back home" },

  // Seminar questions (home)
  seminar_questions: { sw: "Maswali ya Semina", en: "Seminar Questions" },
  seminar_questions_sub: { sw: "Pakua maswali yaliyowekwa na admin.", en: "Download the question papers shared by admin." },
  no_seminar_questions: { sw: "Hakuna maswali ya semina kwa sasa.", en: "No seminar questions available right now." },

  // Group submissions (home)
  submit_group_work: { sw: "Wasilisha Kazi ya Group", en: "Submit Group Work" },
  submit_group_work_sub: { sw: "Pakia PDF ya majibu ya group lako. Admin atayapokea na kuyasaidia.", en: "Upload the PDF answers for your group. Admin will receive and review them." },
  group_name: { sw: "Jina la Group", en: "Group Name" },
  leader_name: { sw: "Jina la Kiongozi", en: "Leader Name" },
  leader_phone: { sw: "Simu ya Kiongozi", en: "Leader Phone" },
  notes_optional: { sw: "Maelezo (hiari)", en: "Notes (optional)" },
  pdf_file: { sw: "PDF ya Kazi", en: "Work PDF" },
  submit: { sw: "Wasilisha", en: "Submit" },
  submitting: { sw: "Inawasilisha...", en: "Submitting..." },
  submission_success: { sw: "Kazi yako imewasilishwa kikamilifu!", en: "Your work has been submitted!" },
  pdf_too_large: { sw: "PDF ni kubwa mno (max 20MB).", en: "PDF too large (max 20MB)." },
  pdf_only: { sw: "Lazima iwe PDF.", en: "Must be a PDF file." },

  // Admin: seminar questions / submissions
  admin_seminar_questions: { sw: "Simamia Maswali ya Semina", en: "Manage Seminar Questions" },
  upload_question_paper: { sw: "Pakia Maswali Mapya", en: "Upload New Question Paper" },
  question_title: { sw: "Kichwa cha Maswali", en: "Question Title" },
  description: { sw: "Maelezo", en: "Description" },
  admin_submissions: { sw: "Kazi Zilizowasilishwa", en: "Submitted Group Work" },
  no_submissions: { sw: "Hakuna kazi iliyowasilishwa bado.", en: "No submissions yet." },
  status: { sw: "Hali", en: "Status" },
  pending: { sw: "Inasubiri", en: "Pending" },
  reviewed: { sw: "Imekaguliwa", en: "Reviewed" },
  mark_reviewed: { sw: "Weka Imekaguliwa", en: "Mark as Reviewed" },
  admin_notes: { sw: "Maoni ya Admin", en: "Admin Notes" },
  save_notes: { sw: "Hifadhi Maoni", en: "Save Notes" },
};

interface I18nCtx {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: keyof typeof dict) => string;
}

const Ctx = createContext<I18nCtx | null>(null);

export const I18nProvider = ({ children }: { children: ReactNode }) => {
  const [lang, setLangState] = useState<Lang>(() => (localStorage.getItem("lang") as Lang) || "sw");
  useEffect(() => { localStorage.setItem("lang", lang); }, [lang]);
  const setLang = (l: Lang) => setLangState(l);
  const t = (key: keyof typeof dict) => dict[key]?.[lang] ?? String(key);
  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
};

export const useI18n = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useI18n must be inside I18nProvider");
  return c;
};

export const LanguageToggle = ({ className = "" }: { className?: string }) => {
  const { lang, setLang } = useI18n();
  return (
    <button
      onClick={() => setLang(lang === "sw" ? "en" : "sw")}
      className={`text-xs font-bold uppercase tracking-widest px-2 py-1 rounded border border-border hover:bg-muted transition-smooth ${className}`}
      aria-label="Toggle language"
    >
      {lang === "sw" ? "EN" : "SW"}
    </button>
  );
};
