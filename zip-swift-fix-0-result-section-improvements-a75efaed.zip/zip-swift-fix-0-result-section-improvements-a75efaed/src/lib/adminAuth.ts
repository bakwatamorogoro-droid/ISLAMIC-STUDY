// Local-only admin auth — haitumii backend.
// Default credentials: 1234 / abdi77. Admin anaweza kubadilisha username + password
// na zinahifadhiwa kwenye localStorage ya kifaa hicho.

const TOKEN_KEY = "is_study_mum_admin_token";
const CREDS_KEY = "is_study_mum_admin_creds";
const DEFAULT_USERNAME = "1234";
const DEFAULT_PASSWORD = "abdi77";
const LOCAL_TOKEN = "local-admin-1234";

export interface AdminInfo {
  id: string;
  username: string;
}

interface StoredCreds { username: string; password: string; }

function readCreds(): StoredCreds {
  try {
    const raw = localStorage.getItem(CREDS_KEY);
    if (raw) {
      const c = JSON.parse(raw);
      if (c?.username && c?.password) return c;
    }
  } catch {}
  return { username: DEFAULT_USERNAME, password: DEFAULT_PASSWORD };
}

function writeCreds(c: StoredCreds) {
  localStorage.setItem(CREDS_KEY, JSON.stringify(c));
}

export function getAdminToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setAdminToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearAdminToken() {
  localStorage.removeItem(TOKEN_KEY);
}

function adminInfo(): AdminInfo {
  return { id: "local-admin", username: readCreds().username };
}

export async function loginAdmin(username: string, password: string) {
  const c = readCreds();
  if (username !== c.username || password !== c.password) {
    throw new Error("Username au password si sahihi");
  }
  setAdminToken(LOCAL_TOKEN);
  return adminInfo();
}

export async function verifyAdmin(): Promise<AdminInfo | null> {
  const token = getAdminToken();
  if (token === LOCAL_TOKEN) return adminInfo();
  if (token) clearAdminToken();
  return null;
}

export async function changeAdminPassword(currentPassword: string, newPassword: string) {
  const c = readCreds();
  if (currentPassword !== c.password) throw new Error("Password ya sasa si sahihi");
  if (!newPassword || newPassword.length < 4) throw new Error("Password mpya iwe na herufi 4+");
  writeCreds({ username: c.username, password: newPassword });
}

export async function changeAdminUsername(currentPassword: string, newUsername: string) {
  const c = readCreds();
  if (currentPassword !== c.password) throw new Error("Password si sahihi");
  const u = newUsername.trim();
  if (!u || u.length < 2) throw new Error("Username iwe na herufi 2+");
  writeCreds({ username: u, password: c.password });
}

export function getAdminUsername(): string {
  return readCreds().username;
}
