import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Mail, Phone, MessageCircle } from "lucide-react";

const SiteFooter = () => {
  const [contact, setContact] = useState<{ email?: string | null; phone?: string | null; whatsapp?: string | null }>({});
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("home_settings" as any)
        .select("admin_email, admin_phone, admin_whatsapp")
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (data) setContact({
        email: (data as any).admin_email,
        phone: (data as any).admin_phone,
        whatsapp: (data as any).admin_whatsapp,
      });
    })();
  }, []);
  const waHref = contact.whatsapp
    ? `https://wa.me/${String(contact.whatsapp).replace(/[^0-9]/g, "")}`
    : null;
  return (
    <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
      <div className="container space-y-3">
        {(contact.email || contact.phone || contact.whatsapp) && (
          <div className="flex items-center justify-center gap-4 flex-wrap text-xs">
            {contact.phone && (
              <a href={`tel:${contact.phone}`} className="inline-flex items-center gap-1 hover:text-foreground transition-smooth font-mono-num">
                <Phone className="h-3.5 w-3.5" /> {contact.phone}
              </a>
            )}
            {waHref && (
              <a href={waHref} target="_blank" rel="noopener noreferrer"
                 className="inline-flex items-center gap-1 hover:text-green-600 transition-smooth font-mono-num">
                <MessageCircle className="h-3.5 w-3.5" /> WhatsApp: {contact.whatsapp}
              </a>
            )}
            {contact.email && (
              <a href={`mailto:${contact.email}`} className="inline-flex items-center gap-1 hover:text-foreground transition-smooth">
                <Mail className="h-3.5 w-3.5" /> {contact.email}
              </a>
            )}
          </div>
        )}
        <div className="brand-wordmark font-extrabold tracking-wider text-base justify-center">
          <span className="brand-word-primary">ISLAMIC</span>{" "}
          <span className="brand-word-primary">STUDIES</span>{" "}
          <span className="brand-word-accent">MUM</span>
        </div>
        <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          Islamic Studies Online Test
        </div>
        <div>© {new Date().getFullYear()} ISLAMIC STUDIES MUM</div>
        <div className="font-semibold text-foreground">
          Designed & Developed by <span className="text-accent">Viwango Stationary</span>
        </div>
        <div className="opacity-40 hover:opacity-100 transition-opacity">
          <Link to="/admin/login" className="text-[10px] uppercase tracking-widest">· Management ·</Link>
        </div>
      </div>
    </footer>
  );
};

export default SiteFooter;
