import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";

/**
 * Lightweight page transition wrapper.
 * Adds a fade + slight upward slide animation each time the route changes,
 * with a brief modern loading overlay (orbital + brand bar) on every navigation.
 */
const PageTransition = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();
  const [displayKey, setDisplayKey] = useState(location.pathname);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setDisplayKey(location.pathname + location.search);
    setLoading(true);
    const t = setTimeout(() => setLoading(false), 520);
    return () => clearTimeout(t);
  }, [location.pathname, location.search]);

  return (
    <>
      {loading && (
        <div className="route-loading-overlay" aria-hidden>
          <div className="route-loading-bar" />
          <div className="route-loading-orb">
            <span className="route-loading-ring" />
            <span className="route-loading-ring delay-1" />
            <span className="route-loading-ring delay-2" />
            <span className="route-loading-dot" />
          </div>
        </div>
      )}
      <div key={displayKey} className="page-transition">
        {children}
      </div>
    </>
  );
};

export default PageTransition;
