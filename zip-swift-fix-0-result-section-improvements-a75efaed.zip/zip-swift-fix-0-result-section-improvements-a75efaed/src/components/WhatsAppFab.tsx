import { MessageCircle } from "lucide-react";
import { useLocation } from "react-router-dom";

interface Props {
  phone?: string;
  message?: string;
}

const WhatsAppFab = ({
  phone = "255000000000",
  message = "Assalaam Alaykum, nina swali kuhusu ISLAMIC STUDIES MUM.",
}: Props) => {
  const { pathname } = useLocation();
  if (pathname !== "/") return null;
  const href = `https://wa.me/${phone.replace(/\D/g, "")}?text=${encodeURIComponent(message)}`;
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Wasiliana nasi WhatsApp"
      className="fixed bottom-5 right-5 z-50 group"
    >
      <span className="absolute inset-0 rounded-full bg-emerald-500/40 animate-ping" aria-hidden />
      <span className="relative flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-[0_10px_30px_-5px_rgba(16,185,129,0.6)] ring-2 ring-white/40 transition-transform duration-300 group-hover:scale-110">
        <MessageCircle className="h-7 w-7" />
      </span>
      <span className="hidden sm:flex absolute right-16 top-1/2 -translate-y-1/2 items-center whitespace-nowrap rounded-xl bg-foreground text-background text-xs font-bold px-3 py-2 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
        Chat WhatsApp
      </span>
    </a>
  );
};

export default WhatsAppFab;
