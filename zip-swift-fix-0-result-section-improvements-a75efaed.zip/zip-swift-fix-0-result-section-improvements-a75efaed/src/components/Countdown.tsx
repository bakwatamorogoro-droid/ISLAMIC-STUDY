import { useEffect, useState } from "react";

interface Props { target: string | Date; label?: string; }

function diff(targetMs: number) {
  const now = Date.now();
  let s = Math.max(0, Math.floor((targetMs - now) / 1000));
  const days = Math.floor(s / 86400); s -= days * 86400;
  const hours = Math.floor(s / 3600); s -= hours * 3600;
  const minutes = Math.floor(s / 60); s -= minutes * 60;
  return { days, hours, minutes, seconds: s, total: targetMs - now };
}

const Cell = ({ n, label }: { n: number; label: string }) => (
  <div className="flex flex-col items-center bg-card/80 backdrop-blur rounded-xl px-3 py-2 min-w-[64px] border border-border shadow-card">
    <span className="font-mono-num text-2xl md:text-3xl font-extrabold text-primary">{String(n).padStart(2, "0")}</span>
    <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</span>
  </div>
);

export default function Countdown({ target, label = "Mtihani Unaanza Baada Ya" }: Props) {
  const targetMs = new Date(target).getTime();
  const [t, setT] = useState(diff(targetMs));

  useEffect(() => {
    const id = setInterval(() => setT(diff(targetMs)), 1000);
    return () => clearInterval(id);
  }, [targetMs]);

  if (t.total <= 0) {
    return (
      <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent font-semibold">
        <span className="h-2 w-2 rounded-full bg-accent animate-pulse" /> Mtihani umeshaanza
      </div>
    );
  }

  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">{label}</p>
      <div className="flex gap-2">
        <Cell n={t.days} label="Siku" />
        <Cell n={t.hours} label="Saa" />
        <Cell n={t.minutes} label="Dak" />
        <Cell n={t.seconds} label="Sek" />
      </div>
    </div>
  );
}
