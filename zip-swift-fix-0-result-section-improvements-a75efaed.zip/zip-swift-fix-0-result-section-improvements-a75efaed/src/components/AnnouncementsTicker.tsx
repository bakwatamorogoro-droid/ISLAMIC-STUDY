import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Megaphone, Radio } from "lucide-react";

interface Ann { id: string; title: string; body: string; created_at: string; }

const AnnouncementsTicker = () => {
  const [items, setItems] = useState<Ann[]>([]);
  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from("announcements" as any)
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false })
        .limit(8);
      setItems((data as any) || []);
    };
    load();
    const ch = supabase
      .channel("announcements_ticker")
      .on("postgres_changes", { event: "*", schema: "public", table: "announcements" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  if (items.length === 0) return null;
  // Triple the items so the marquee loop is seamless even with few items.
  const repeated = [...items, ...items, ...items];

  return (
    <section className="container -mt-6 relative z-20">
      <div className="rounded-2xl bg-gradient-hero text-primary-foreground shadow-elegant overflow-hidden border border-primary-glow/30">
        <div className="flex items-stretch">
          <div className="shrink-0 px-4 py-3 bg-accent text-accent-foreground flex items-center gap-2 font-bold text-xs uppercase tracking-widest">
            <Radio className="h-4 w-4 animate-pulse" /> News
          </div>
          <div className="flex-1 overflow-hidden relative">
            <div
              className="flex gap-10 whitespace-nowrap py-3 px-4 will-change-transform"
              style={{
                animation: "marquee 35s linear infinite",
                width: "max-content",
              }}
            >
              {repeated.map((a, i) => (
                <span key={`${a.id}-${i}`} className="inline-flex items-center gap-2 text-sm">
                  <span className="h-2 w-2 rounded-full bg-accent-glow inline-block animate-pulse" />
                  <strong className="font-bold">{a.title}</strong>
                  <span className="opacity-80">— {a.body}</span>
                  <span className="mx-3 opacity-30">•</span>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          0%   { transform: translateX(0); }
          100% { transform: translateX(-33.333%); }
        }
      `}</style>
    </section>
  );
};

export default AnnouncementsTicker;
