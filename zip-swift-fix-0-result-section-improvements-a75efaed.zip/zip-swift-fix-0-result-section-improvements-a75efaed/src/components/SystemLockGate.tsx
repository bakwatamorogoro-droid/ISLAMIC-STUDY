import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Lock } from "lucide-react";

interface LockState {
  locked: boolean;
  message: string;
  email?: string | null;
  phone?: string | null;
}

// Routes that admins use — never blocked.
const ADMIN_PREFIXES = ["/admin"];

const SystemLockGate = ({ children }: { children: ReactNode }) => {
  const location = useLocation();
  const [state, setState] = useState<LockState>({ locked: false, message: "" });
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      const { data } = await supabase
        .from("home_settings" as any)
        .select("system_locked, lock_message, admin_email, admin_phone")
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (!mounted) return;
      const d = (data as any) || {};
      setState({
        locked: !!d.system_locked,
        message: d.lock_message || "",
        email: d.admin_email,
        phone: d.admin_phone,
      });
      setLoaded(true);
    };
    load();
    // Realtime so when admin flips the switch, students see it.
    const ch = supabase
      .channel("home_settings_lock")
      .on("postgres_changes", { event: "*", schema: "public", table: "home_settings" }, load)
      .subscribe();
    return () => { mounted = false; supabase.removeChannel(ch); };
  }, []);

  const isAdminRoute = ADMIN_PREFIXES.some((p) => location.pathname.startsWith(p));

  if (!loaded) return <>{children}</>;
  if (!state.locked || isAdminRoute) return <>{children}</>;

  return (
    <div className="min-h-screen bg-background grid place-items-center p-6">
      <div className="max-w-md w-full text-center bg-card border border-border rounded-2xl shadow-elegant p-8">
        <div className="h-16 w-16 mx-auto mb-4 rounded-2xl bg-destructive/10 text-destructive grid place-items-center">
          <Lock className="h-8 w-8" />
        </div>
        <h1 className="text-2xl font-extrabold mb-2">System Locked</h1>
        <p className="text-sm text-muted-foreground whitespace-pre-line mb-4">
          {state.message || "Mfumo umefungwa kwa muda na admin. Tafadhali subiri."}
        </p>
        {(state.email || state.phone) && (
          <div className="pt-4 border-t border-border text-xs text-muted-foreground space-y-1">
            <p className="font-semibold text-foreground">Wasiliana na admin:</p>
            {state.email && <p>📧 <a href={`mailto:${state.email}`} className="text-primary hover:underline">{state.email}</a></p>}
            {state.phone && <p>📞 <a href={`tel:${state.phone}`} className="text-primary hover:underline font-mono-num">{state.phone}</a></p>}
          </div>
        )}
      </div>
      {/* Hidden admin access — barely visible dot, only admin knows it's clickable */}
      <Link
        to="/admin/login"
        aria-label="Management"
        title="Management"
        className="fixed bottom-2 right-2 h-3 w-3 rounded-full bg-muted-foreground/10 hover:bg-muted-foreground/40 transition-colors"
      />
    </div>
  );
};

export default SystemLockGate;
