export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_sessions: {
        Row: {
          admin_id: string
          created_at: string
          expires_at: string
          id: string
          token: string
        }
        Insert: {
          admin_id: string
          created_at?: string
          expires_at?: string
          id?: string
          token: string
        }
        Update: {
          admin_id?: string
          created_at?: string
          expires_at?: string
          id?: string
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_sessions_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_users: {
        Row: {
          created_at: string
          id: string
          password_hash: string
          username: string
        }
        Insert: {
          created_at?: string
          id?: string
          password_hash: string
          username: string
        }
        Update: {
          created_at?: string
          id?: string
          password_hash?: string
          username?: string
        }
        Relationships: []
      }
      announcements: {
        Row: {
          body: string | null
          created_at: string
          id: string
          is_active: boolean
          title: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          title: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          title?: string
        }
        Relationships: []
      }
      answers: {
        Row: {
          answer_text: string | null
          attempt_id: string
          awarded_marks: number | null
          created_at: string
          id: string
          is_correct: boolean | null
          long_answer: string | null
          needs_grading: boolean | null
          question_id: string
          short_answer: string | null
        }
        Insert: {
          answer_text?: string | null
          attempt_id: string
          awarded_marks?: number | null
          created_at?: string
          id?: string
          is_correct?: boolean | null
          long_answer?: string | null
          needs_grading?: boolean | null
          question_id: string
          short_answer?: string | null
        }
        Update: {
          answer_text?: string | null
          attempt_id?: string
          awarded_marks?: number | null
          created_at?: string
          id?: string
          is_correct?: boolean | null
          long_answer?: string | null
          needs_grading?: boolean | null
          question_id?: string
          short_answer?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "answers_attempt_id_fkey"
            columns: ["attempt_id"]
            isOneToOne: false
            referencedRelation: "attempts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
        ]
      }
      attempts: {
        Row: {
          auto_submitted: boolean
          created_at: string
          exam_id: string
          id: string
          needs_grading: boolean
          published: boolean
          question_order: Json | null
          score: number
          started_at: string
          status: string
          student_id: string
          submitted_at: string | null
          terminated: boolean
          total_marks: number
          violation_reason: string | null
        }
        Insert: {
          auto_submitted?: boolean
          created_at?: string
          exam_id: string
          id?: string
          needs_grading?: boolean
          published?: boolean
          question_order?: Json | null
          score?: number
          started_at?: string
          status?: string
          student_id: string
          submitted_at?: string | null
          terminated?: boolean
          total_marks?: number
          violation_reason?: string | null
        }
        Update: {
          auto_submitted?: boolean
          created_at?: string
          exam_id?: string
          id?: string
          needs_grading?: boolean
          published?: boolean
          question_order?: Json | null
          score?: number
          started_at?: string
          status?: string
          student_id?: string
          submitted_at?: string | null
          terminated?: boolean
          total_marks?: number
          violation_reason?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "attempts_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attempts_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_records: {
        Row: {
          confirmed_at: string
          course: string | null
          distance_m: number | null
          full_name: string | null
          id: string
          reg_no: string
          session_id: string
        }
        Insert: {
          confirmed_at?: string
          course?: string | null
          distance_m?: number | null
          full_name?: string | null
          id?: string
          reg_no: string
          session_id: string
        }
        Update: {
          confirmed_at?: string
          course?: string | null
          distance_m?: number | null
          full_name?: string | null
          id?: string
          reg_no?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_records_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "attendance_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_sessions: {
        Row: {
          created_at: string
          id: string
          is_open: boolean
          location_lat: number | null
          location_lng: number | null
          location_radius_m: number | null
          location_required: boolean
          notes: string | null
          session_date: string
          title: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_open?: boolean
          location_lat?: number | null
          location_lng?: number | null
          location_radius_m?: number | null
          location_required?: boolean
          notes?: string | null
          session_date?: string
          title: string
        }
        Update: {
          created_at?: string
          id?: string
          is_open?: boolean
          location_lat?: number | null
          location_lng?: number | null
          location_radius_m?: number | null
          location_required?: boolean
          notes?: string | null
          session_date?: string
          title?: string
        }
        Relationships: []
      }
      exam_marks: {
        Row: {
          contribution: number | null
          created_at: string
          exam_id: string | null
          full_name: string | null
          id: string
          max_score: number | null
          presentation: number | null
          reg_no: string | null
          score: number | null
          test1: number | null
          test2: number | null
          updated_at: string
        }
        Insert: {
          contribution?: number | null
          created_at?: string
          exam_id?: string | null
          full_name?: string | null
          id?: string
          max_score?: number | null
          presentation?: number | null
          reg_no?: string | null
          score?: number | null
          test1?: number | null
          test2?: number | null
          updated_at?: string
        }
        Update: {
          contribution?: number | null
          created_at?: string
          exam_id?: string | null
          full_name?: string | null
          id?: string
          max_score?: number | null
          presentation?: number | null
          reg_no?: string | null
          score?: number | null
          test1?: number | null
          test2?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_marks_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
        ]
      }
      exams: {
        Row: {
          created_at: string
          description: string | null
          duration_seconds: number
          id: string
          is_active: boolean
          location_lat: number | null
          location_lng: number | null
          location_radius_m: number
          location_required: boolean
          results_published: boolean
          scheduled_end_at: string | null
          scheduled_start_at: string | null
          shuffle_questions: boolean
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          duration_seconds?: number
          id?: string
          is_active?: boolean
          location_lat?: number | null
          location_lng?: number | null
          location_radius_m?: number
          location_required?: boolean
          results_published?: boolean
          scheduled_end_at?: string | null
          scheduled_start_at?: string | null
          shuffle_questions?: boolean
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          duration_seconds?: number
          id?: string
          is_active?: boolean
          location_lat?: number | null
          location_lng?: number | null
          location_radius_m?: number
          location_required?: boolean
          results_published?: boolean
          scheduled_end_at?: string | null
          scheduled_start_at?: string | null
          shuffle_questions?: boolean
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      group_members: {
        Row: {
          contribution: number | null
          course: string | null
          created_at: string
          full_name: string
          gender: string | null
          group_id: string
          id: string
          mobile_no: string | null
          presentation: number | null
          reg_no: string
          test1: number | null
          test2: number | null
        }
        Insert: {
          contribution?: number | null
          course?: string | null
          created_at?: string
          full_name: string
          gender?: string | null
          group_id: string
          id?: string
          mobile_no?: string | null
          presentation?: number | null
          reg_no: string
          test1?: number | null
          test2?: number | null
        }
        Update: {
          contribution?: number | null
          course?: string | null
          created_at?: string
          full_name?: string
          gender?: string | null
          group_id?: string
          id?: string
          mobile_no?: string | null
          presentation?: number | null
          reg_no?: string
          test1?: number | null
          test2?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
        ]
      }
      group_submissions: {
        Row: {
          admin_notes: string | null
          created_at: string
          group_name: string | null
          id: string
          leader_name: string | null
          leader_phone: string | null
          notes: string | null
          pdf_url: string | null
          semester: string | null
          status: string
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          group_name?: string | null
          id?: string
          leader_name?: string | null
          leader_phone?: string | null
          notes?: string | null
          pdf_url?: string | null
          semester?: string | null
          status?: string
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          group_name?: string | null
          id?: string
          leader_name?: string | null
          leader_phone?: string | null
          notes?: string | null
          pdf_url?: string | null
          semester?: string | null
          status?: string
        }
        Relationships: []
      }
      groups: {
        Row: {
          created_at: string
          group_number: number
          id: string
          location_lat: number | null
          location_lng: number | null
          location_radius_m: number | null
          location_required: boolean
          semester_id: string | null
          student_limit: number | null
          title: string | null
        }
        Insert: {
          created_at?: string
          group_number?: number
          id?: string
          location_lat?: number | null
          location_lng?: number | null
          location_radius_m?: number | null
          location_required?: boolean
          semester_id?: string | null
          student_limit?: number | null
          title?: string | null
        }
        Update: {
          created_at?: string
          group_number?: number
          id?: string
          location_lat?: number | null
          location_lng?: number | null
          location_radius_m?: number | null
          location_required?: boolean
          semester_id?: string | null
          student_limit?: number | null
          title?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "groups_semester_id_fkey"
            columns: ["semester_id"]
            isOneToOne: false
            referencedRelation: "semesters"
            referencedColumns: ["id"]
          },
        ]
      }
      home_settings: {
        Row: {
          admin_email: string | null
          admin_phone: string | null
          admin_whatsapp: string | null
          allow_student_edits: boolean
          created_at: string
          empty_exams_message: string | null
          hero_subtitle: string | null
          hero_title: string | null
          id: string
          lock_message: string | null
          system_locked: boolean
          updated_at: string
        }
        Insert: {
          admin_email?: string | null
          admin_phone?: string | null
          admin_whatsapp?: string | null
          allow_student_edits?: boolean
          created_at?: string
          empty_exams_message?: string | null
          hero_subtitle?: string | null
          hero_title?: string | null
          id?: string
          lock_message?: string | null
          system_locked?: boolean
          updated_at?: string
        }
        Update: {
          admin_email?: string | null
          admin_phone?: string | null
          admin_whatsapp?: string | null
          allow_student_edits?: boolean
          created_at?: string
          empty_exams_message?: string | null
          hero_subtitle?: string | null
          hero_title?: string | null
          id?: string
          lock_message?: string | null
          system_locked?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      questions: {
        Row: {
          correct_answer: string | null
          created_at: string
          exam_id: string
          id: string
          marks: number
          options: Json | null
          position: number
          question_text: string
          question_type: string
        }
        Insert: {
          correct_answer?: string | null
          created_at?: string
          exam_id: string
          id?: string
          marks?: number
          options?: Json | null
          position?: number
          question_text: string
          question_type?: string
        }
        Update: {
          correct_answer?: string | null
          created_at?: string
          exam_id?: string
          id?: string
          marks?: number
          options?: Json | null
          position?: number
          question_text?: string
          question_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "questions_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
        ]
      }
      semesters: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          title: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          title: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          title?: string
        }
        Relationships: []
      }
      seminar_questions: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          pdf_url: string
          title: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          pdf_url: string
          title: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          pdf_url?: string
          title?: string
        }
        Relationships: []
      }
      student_edit_requests: {
        Row: {
          admin_notes: string | null
          created_at: string
          current_full_name: string | null
          current_reg_no: string | null
          id: string
          reason: string | null
          requested_full_name: string | null
          requested_reg_no: string | null
          reviewed_at: string | null
          score_snapshot: number | null
          status: string
          student_id: string | null
          submitted_full_name: string | null
          submitted_reg_no: string | null
          total_snapshot: number | null
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          current_full_name?: string | null
          current_reg_no?: string | null
          id?: string
          reason?: string | null
          requested_full_name?: string | null
          requested_reg_no?: string | null
          reviewed_at?: string | null
          score_snapshot?: number | null
          status?: string
          student_id?: string | null
          submitted_full_name?: string | null
          submitted_reg_no?: string | null
          total_snapshot?: number | null
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          current_full_name?: string | null
          current_reg_no?: string | null
          id?: string
          reason?: string | null
          requested_full_name?: string | null
          requested_reg_no?: string | null
          reviewed_at?: string | null
          score_snapshot?: number | null
          status?: string
          student_id?: string | null
          submitted_full_name?: string | null
          submitted_reg_no?: string | null
          total_snapshot?: number | null
        }
        Relationships: []
      }
      students: {
        Row: {
          course: string | null
          created_at: string
          exam_number: string
          full_name: string
          id: string
          mobile_no: string | null
          reg_no: string | null
        }
        Insert: {
          course?: string | null
          created_at?: string
          exam_number: string
          full_name: string
          id?: string
          mobile_no?: string | null
          reg_no?: string | null
        }
        Update: {
          course?: string | null
          created_at?: string
          exam_number?: string
          full_name?: string
          id?: string
          mobile_no?: string | null
          reg_no?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
