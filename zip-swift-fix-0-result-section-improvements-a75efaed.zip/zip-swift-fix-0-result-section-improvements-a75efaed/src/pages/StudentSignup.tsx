import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { UserPlus, ArrowLeft, CheckCircle2, MapPin, Loader2 } from "lucide-react";
import { distanceMeters, getCurrentPosition } from "@/lib/geo";
import { useI18n, LanguageToggle } from "@/lib/i18n";

interface Semester { id: string; title: string; }
interface Group {
  id: string; group_number: number; title: string | null; semester_id: string;
  location_required?: boolean; location_lat?: number | null; location_lng?: number | null; location_radius_m?: number;
  student_limit?: number | null;
}

const REG_NO_REGEX = /^(MUM)?\d{4}-\d{2}-?\d{3,6}$/i;

const StudentSignup = () => {
  const navigate = useNavigate();
  const { t } = useI18n();
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [groupCounts, setGroupCounts] = useState<Record<string, number>>({});
  const [semesterId, setSemesterId] = useState("");
  const [groupId, setGroupId] = useState("");
  const [fullName, setFullName] = useState("");
  const [regNo, setRegNo] = useState("");
  const [mobile, setMobile] = useState("");
  const [gender, setGender] = useState("");
  const [course, setCourse] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [doneGroup, setDoneGroup] = useState<Group | null>(null);

  useEffect(() => {
    supabase.from("semesters").select("id,title").eq("is_active", true)
      .order("created_at", { ascending: false }).then(({ data }) => {
        setSemesters(data || []);
        if (data && data.length > 0) setSemesterId(data[0].id);
      });
  }, []);

  useEffect(() => {
    if (!semesterId) { setGroups([]); setGroupId(""); return; }
    supabase.from("groups").select("id,group_number,title,semester_id,location_required,location_lat,location_lng,location_radius_m,student_limit")
      .eq("semester_id", semesterId).order("group_number").then(async ({ data }) => {
        const gs = (data as any) || [];
        setGroups(gs);
        if (gs.length > 0) {
          const { data: mems } = await supabase.from("group_members").select("group_id").in("group_id", gs.map((g: any) => g.id));
          const counts: Record<string, number> = {};
          (mems || []).forEach((m: any) => { counts[m.group_id] = (counts[m.group_id] || 0) + 1; });
          setGroupCounts(counts);
          const firstAvail = gs.find((g: any) => !g.student_limit || (counts[g.id] || 0) < g.student_limit);
          setGroupId(firstAvail?.id || gs[0].id);
        } else {
          setGroupId("");
        }
      });
  }, [semesterId]);

  const selectedGroup = groups.find((g) => g.id === groupId);
  const selectedCount = selectedGroup ? (groupCounts[selectedGroup.id] || 0) : 0;
  const groupFull = false; // limit removed — unlimited registrations allowed

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    const reg = regNo.trim().toUpperCase();
    const name = fullName.trim();
    if (!name || !reg || !groupId) return toast.error("!");
    if (!gender) return toast.error("!");
    if (!course.trim()) return toast.error("!");
    if (!REG_NO_REGEX.test(reg)) {
      return toast.error("Reg No format invalid. e.g. 2021-04-93392 or MUM2021-04578");
    }
    if (groupFull) return toast.error(t("group_full_msg"));

    setLoading(true);
    try {
      const { data: existing } = await supabase
        .from("group_members")
        .select("id, full_name, group_id")
        .ilike("reg_no", reg)
        .maybeSingle();

      if (existing) {
        toast.error("Reg No hii tayari imejisajili — huwezi kujisajili mara mbili.");
        setLoading(false);
        return;
      }
      // Limit removed — seminars accept unlimited students.

      if (selectedGroup?.location_required && selectedGroup.location_lat != null && selectedGroup.location_lng != null) {
        try {
          const pos = await getCurrentPosition();
          const dist = distanceMeters(pos.lat, pos.lng, selectedGroup.location_lat, selectedGroup.location_lng);
          const radius = selectedGroup.location_radius_m || 200;
          if (dist > radius) {
            toast.error(`GPS: ~${Math.round(dist)}m / max ${radius}m`);
            setLoading(false);
            return;
          }
          toast.success(`GPS ✓ (~${Math.round(dist)}m)`);
        } catch (geoErr: any) {
          toast.error(geoErr.message || "GPS error");
          setLoading(false);
          return;
        }
      }

      const { error } = await supabase.from("group_members").insert({
        group_id: groupId,
        full_name: name,
        reg_no: reg,
        mobile_no: mobile.trim() || null,
        gender,
        course: course.trim(),
      });
      if (error) throw error;
      toast.success(t("done_title"));
      setDoneGroup(selectedGroup || null);
      setDone(true);
    } catch (err: any) {
      toast.error(err.message || "Error");
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-background grid place-items-center p-6">
        <Card className="p-8 max-w-md w-full text-center shadow-elegant">
          <div className="inline-flex h-16 w-16 rounded-2xl bg-accent/10 text-accent items-center justify-center mb-4">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-extrabold mb-2">{t("done_title")}</h1>
          <p className="text-sm text-muted-foreground mb-6">{t("done_sub")}</p>

          {/* Seminar question PDFs are shown on the home page */}

          <div className="flex gap-3">
            <Button asChild variant="outline" className="flex-1"><Link to="/">{t("home")}</Link></Button>
            <Button asChild className="flex-1"><Link to="/exam/register">{t("take_exam")}</Link></Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> {t("back_home")}
          </Link>
          <LanguageToggle />
        </div>
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-hero items-center justify-center mb-4 text-primary-foreground shadow-elegant">
              <UserPlus className="h-7 w-7" />
            </div>
            <h1 className="text-3xl font-extrabold mb-2">{t("signup_seminar")}</h1>
            <p className="text-muted-foreground text-sm">{t("signup_sub")}</p>
          </div>

          <Card className="p-6 shadow-card">
            <form onSubmit={handleSignup} className="space-y-4">
              <div>
                <Label htmlFor="sem">{t("semester")}</Label>
                <select id="sem" value={semesterId} onChange={(e) => setSemesterId(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
                  {semesters.length === 0 && <option value="">—</option>}
                  {semesters.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}
                </select>
              </div>
              <div>
                <Label htmlFor="grp">{t("group")}</Label>
                <select id="grp" value={groupId} onChange={(e) => setGroupId(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
                  {groups.length === 0 && <option value="">—</option>}
                  {groups.map((g) => {
                    const c = groupCounts[g.id] || 0;
                    const full = !!(g.student_limit && c >= g.student_limit);
                    return (
                      <option key={g.id} value={g.id}>
                        Group {g.group_number}{g.title ? ` — ${g.title}` : ""}
                        {g.student_limit ? ` (${c}/${g.student_limit})` : ""}
                        {full ? ` — ${t("group_full")}` : ""}
                      </option>
                    );
                  })}
                </select>
                {selectedGroup?.student_limit && (
                  <p className="text-[11px] text-muted-foreground mt-1 font-mono-num">
                    {t("students_word")}: {selectedCount}/{selectedGroup.student_limit}
                  </p>
                )}
              </div>
              {groupFull && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-xs text-destructive font-semibold">
                  ⚠ {t("group_full_msg")}
                </div>
              )}
              {selectedGroup?.location_required && (
                <div className="p-3 rounded-lg bg-warning/5 border border-warning/30 text-xs flex gap-2">
                  <MapPin className="h-4 w-4 text-warning shrink-0 mt-0.5" />
                  <div>
                    <strong>GPS required.</strong> Within {selectedGroup.location_radius_m || 200}m of seminar location. Allow location when prompted.
                  </div>
                </div>
              )}
              <div>
                <Label htmlFor="name">{t("full_name")}</Label>
                <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)}
                  placeholder="John Mwakalonge" required />
              </div>
              <div>
                <Label htmlFor="reg">{t("reg_no")}</Label>
                <Input id="reg" value={regNo} onChange={(e) => setRegNo(e.target.value.toUpperCase())}
                  placeholder="2021-04-93392 / MUM2021-04578" required className="font-mono-num" />
              </div>
              <div>
                <Label htmlFor="gender">{t("gender")}</Label>
                <select id="gender" value={gender} onChange={(e) => setGender(e.target.value)} required
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
                  <option value="">{t("choose_dash")}</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
              <div>
                <Label htmlFor="course">{t("course_studying")}</Label>
                <Input id="course" value={course} onChange={(e) => setCourse(e.target.value)}
                  placeholder="BSc Information Systems" required />
              </div>
              <div>
                <Label htmlFor="mob">{t("mobile_optional")}</Label>
                <Input id="mob" value={mobile} onChange={(e) => setMobile(e.target.value)}
                  placeholder="07XXXXXXXX" className="font-mono-num" />
              </div>
              <Button type="submit" className="w-full" disabled={loading || !groupId || groupFull}>
                {loading ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> {t("signing_up")}</>) : groupFull ? t("group_full") : t("signup_btn")}
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default StudentSignup;
