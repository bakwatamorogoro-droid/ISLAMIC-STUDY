import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Shield, Plus, LogOut, GraduationCap, Trash2, Edit, FileText, Users, MapPin, Crosshair, Megaphone, CalendarClock, Inbox, KeyRound, Loader2, Home, Lock, Unlock, FileDown, FileSpreadsheet } from "lucide-react";
import { Switch as UISwitch } from "@/components/ui/switch";
import { clearAdminToken, verifyAdmin, AdminInfo, changeAdminPassword, changeAdminUsername } from "@/lib/adminAuth";
import { formatHMS } from "@/lib/format";
import { LanguageToggle } from "@/lib/i18n";
import { getCurrentPosition } from "@/lib/geo";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import BrandLockup from "@/components/BrandLockup";

interface Exam {
  id: string; title: string; description: string | null;
  duration_seconds: number; is_active: boolean; shuffle_questions: boolean;
  location_lat: number | null; location_lng: number | null;
  location_radius_m: number; location_required: boolean;
  scheduled_start_at: string | null;
  scheduled_end_at: string | null;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [admin, setAdmin] = useState<AdminInfo | null>(null);
  const [exams, setExams] = useState<Exam[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Exam | null>(null);

  // form fields
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(30);
  const [seconds, setSeconds] = useState(0);
  const [active, setActive] = useState(true);
  const [shuffleQ, setShuffleQ] = useState(true);
  const [locationRequired, setLocationRequired] = useState(false);
  const [locLat, setLocLat] = useState<string>("");
  const [locLng, setLocLng] = useState<string>("");
  const [locRadius, setLocRadius] = useState<number>(200);
  const [scheduledStart, setScheduledStart] = useState<string>("");
  const [scheduledEnd, setScheduledEnd] = useState<string>("");

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      setAdmin(a);
      loadExams();
    });
  }, [navigate]);

  const loadExams = async () => {
    const { data } = await supabase.from("exams").select("*").order("created_at", { ascending: false });
    setExams((data as any) || []);
  };

  const openCreate = () => {
    setEditing(null);
    setTitle(""); setDescription(""); setHours(0); setMinutes(30); setSeconds(0);
    setActive(true); setShuffleQ(true);
    setLocationRequired(false); setLocLat(""); setLocLng(""); setLocRadius(200);
    setScheduledStart("");
    setScheduledEnd("");
    setShowForm(true);
  };

  const openEdit = (e: Exam) => {
    setEditing(e);
    setTitle(e.title); setDescription(e.description || "");
    const total = e.duration_seconds;
    setHours(Math.floor(total / 3600));
    setMinutes(Math.floor((total % 3600) / 60));
    setSeconds(total % 60);
    setActive(e.is_active); setShuffleQ(e.shuffle_questions);
    setLocationRequired(!!e.location_required);
    setLocLat(e.location_lat != null ? String(e.location_lat) : "");
    setLocLng(e.location_lng != null ? String(e.location_lng) : "");
    setLocRadius(e.location_radius_m || 200);
    // datetime-local needs format YYYY-MM-DDTHH:mm
    const toLocal = (iso: string) => {
      const d = new Date(iso);
      const pad = (n: number) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    };
    setScheduledStart(e.scheduled_start_at ? toLocal(e.scheduled_start_at) : "");
    setScheduledEnd(e.scheduled_end_at ? toLocal(e.scheduled_end_at) : "");
    setShowForm(true);
  };

  const useMyLocation = async () => {
    toast.info("Getting your location...");
    try {
      const pos = await getCurrentPosition(20000);
      setLocLat(pos.lat.toFixed(6));
      setLocLng(pos.lng.toFixed(6));
      toast.success(`Location set (±${Math.round(pos.accuracy)}m)`);
    } catch (e: any) {
      toast.error(e.message || "Failed to get location");
    }
  };

  // Password change
  const [showPwd, setShowPwd] = useState(false);
  const [curPwd, setCurPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [newPwd2, setNewPwd2] = useState("");
  const [pwdLoading, setPwdLoading] = useState(false);
  const [newUsername, setNewUsername] = useState("");
  const [usrLoading, setUsrLoading] = useState(false);

  const submitPwd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPwd !== newPwd2) return toast.error("New passwords do not match");
    if (newPwd.length < 4) return toast.error("Password must be at least 4 characters");
    setPwdLoading(true);
    try {
      await changeAdminPassword(curPwd, newPwd);
      toast.success("Password imebadilishwa");
      setCurPwd(""); setNewPwd(""); setNewPwd2("");
    } catch (err: any) {
      toast.error(err.message || "Failed");
    } finally { setPwdLoading(false); }
  };

  const submitUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !curPwd) return toast.error("Jaza username + password");
    setUsrLoading(true);
    try {
      await changeAdminUsername(curPwd, newUsername.trim());
      toast.success(`Username imebadilishwa "${newUsername.trim()}". Ingia tena.`);
      clearAdminToken();
      navigate("/admin/login");
    } catch (err: any) {
      toast.error(err.message || "Failed");
    } finally { setUsrLoading(false); }
  };

  // Home page settings (now also includes system lock + admin contacts)
  const [showHome, setShowHome] = useState(false);
  const [homeId, setHomeId] = useState<string | null>(null);
  const [heroTitle, setHeroTitle] = useState("");
  const [heroSubtitle, setHeroSubtitle] = useState("");
  const [emptyMsg, setEmptyMsg] = useState("");
  const [systemLocked, setSystemLocked] = useState(false);
  const [lockMessage, setLockMessage] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPhone, setAdminPhone] = useState("");
  const [adminWhatsapp, setAdminWhatsapp] = useState("");
  const [bannerImageUrl, setBannerImageUrl] = useState("");
  const [bannerUploading, setBannerUploading] = useState(false);
  const [homeLoading, setHomeLoading] = useState(false);

  const loadHomeSettings = async () => {
    const { data } = await supabase
      .from("home_settings" as any)
      .select("*")
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (data) {
      const d = data as any;
      setHomeId(d.id);
      setHeroTitle(d.hero_title || "");
      setHeroSubtitle(d.hero_subtitle || "");
      setEmptyMsg(d.empty_exams_message || "");
      setSystemLocked(!!d.system_locked);
      setLockMessage(d.lock_message || "");
      setAdminEmail(d.admin_email || "");
      setAdminPhone(d.admin_phone || "");
      setAdminWhatsapp(d.admin_whatsapp || "");
      setBannerImageUrl(d.banner_image_url || "");
    }
  };

  const onBannerFile = async (file: File | null) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Picha tu (JPG/PNG/WebP)"); return; }
    if (file.size > 8 * 1024 * 1024) { toast.error("Picha kubwa sana (max 8MB)"); return; }
    setBannerUploading(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `banner-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from("banner-images").upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("banner-images").getPublicUrl(path);
      setBannerImageUrl(pub.publicUrl);
      // Save immediately so it shows on home
      const payload: any = { banner_image_url: pub.publicUrl, updated_at: new Date().toISOString() };
      if (homeId) await supabase.from("home_settings" as any).update(payload).eq("id", homeId);
      else {
        const { data } = await supabase.from("home_settings" as any).insert(payload).select().single();
        if (data) setHomeId((data as any).id);
      }
      toast.success("Picha ya banner imepakiwa.");
    } catch (e: any) {
      toast.error(e.message || "Imeshindikana kupakia picha.");
    } finally {
      setBannerUploading(false);
    }
  };

  const removeBanner = async () => {
    setBannerImageUrl("");
    if (homeId) await supabase.from("home_settings" as any)
      .update({ banner_image_url: null, updated_at: new Date().toISOString() }).eq("id", homeId);
    toast.success("Picha imefutwa.");
  };

  useEffect(() => { loadHomeSettings(); }, []);

  const openHome = async () => {
    await loadHomeSettings();
    setShowHome((s) => !s);
  };

  const saveHome = async (e: React.FormEvent) => {
    e.preventDefault();
    setHomeLoading(true);
    try {
      const payload = {
        hero_title: heroTitle.trim(),
        hero_subtitle: heroSubtitle.trim(),
        empty_exams_message: emptyMsg.trim(),
        system_locked: systemLocked,
        lock_message: lockMessage.trim() || "Mfumo umefungwa kwa muda na admin. Tafadhali subiri.",
        admin_email: adminEmail.trim() || null,
        admin_phone: adminPhone.trim() || null,
        admin_whatsapp: adminWhatsapp.trim() || null,
        banner_image_url: bannerImageUrl.trim() || null,
        updated_at: new Date().toISOString(),
      };
      if (homeId) {
        const { error } = await supabase.from("home_settings" as any).update(payload).eq("id", homeId);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from("home_settings" as any).insert(payload).select().single();
        if (error) throw error;
        if (data) setHomeId((data as any).id);
      }
      toast.success("Settings saved");
    } catch (err: any) {
      toast.error(err.message || "Failed to save");
    } finally {
      setHomeLoading(false);
    }
  };

  const quickToggleLock = async () => {
    const next = !systemLocked;
    setSystemLocked(next);
    try {
      const payload: any = {
        system_locked: next,
        updated_at: new Date().toISOString(),
      };
      if (homeId) {
        await supabase.from("home_settings" as any).update(payload).eq("id", homeId);
      } else {
        const { data } = await supabase.from("home_settings" as any).insert(payload).select().single();
        if (data) setHomeId((data as any).id);
      }
      toast.success(next ? "🔒 Mfumo umefungwa kwa wanafunzi" : "🔓 Mfumo umefunguliwa");
    } catch (err: any) {
      toast.error(err.message || "Failed");
      setSystemLocked(!next);
    }
  };

  const saveExam = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const duration = hours * 3600 + minutes * 60 + seconds;
    if (duration <= 0) { toast.error("Duration must be greater than 0."); return; }
    if (locationRequired && (!locLat || !locLng)) {
      toast.error("Enter latitude and longitude or use 'Use my location'");
      return;
    }
    const payload: any = {
      title, description: description || null, duration_seconds: duration,
      is_active: active, shuffle_questions: shuffleQ,
      location_required: locationRequired,
      location_lat: locationRequired && locLat ? parseFloat(locLat) : null,
      location_lng: locationRequired && locLng ? parseFloat(locLng) : null,
      location_radius_m: locRadius || 200,
      scheduled_start_at: scheduledStart ? new Date(scheduledStart).toISOString() : null,
      scheduled_end_at: scheduledEnd ? new Date(scheduledEnd).toISOString() : null,
    };
    if (editing) {
      const { error } = await supabase.from("exams").update(payload).eq("id", editing.id);
      if (error) return toast.error(error.message);
      toast.success("Exam updated");
    } else {
      const { error } = await supabase.from("exams").insert(payload);
      if (error) return toast.error(error.message);
      toast.success("Exam created");
    }
    setShowForm(false);
    loadExams();
  };

  const deleteExam = async (id: string) => {
    if (!confirm("Una uhakika kufuta mtihani huu? Maswali, attempts, majibu na alama zote za wanafunzi zitafutwa kabisa.")) return;
    try {
      // Get all attempts for this exam to delete their answers
      const { data: atts } = await supabase.from("attempts").select("id").eq("exam_id", id);
      const attemptIds = (atts || []).map((a: any) => a.id);
      if (attemptIds.length > 0) {
        await supabase.from("answers").delete().in("attempt_id", attemptIds);
      }
      await supabase.from("attempts").delete().eq("exam_id", id);
      await supabase.from("questions").delete().eq("exam_id", id);
      await supabase.from("exam_marks").delete().eq("exam_id", id);
      const { error } = await supabase.from("exams").delete().eq("id", id);
      if (error) throw error;
      toast.success("Mtihani na taarifa zote za wanafunzi zimefutwa");
      loadExams();
    } catch (e: any) {
      toast.error(e.message || "Imeshindikana kufuta");
    }
  };

  const logout = () => { clearAdminToken(); navigate("/admin/login"); };

  const buildExamRows = () => exams.map((e, i) => ({
    "#": i + 1,
    "Title": e.title,
    "Description": e.description || "",
    "Duration": formatHMS(e.duration_seconds),
    "Status": e.is_active ? "Active" : "Inactive",
    "Shuffle": e.shuffle_questions ? "Yes" : "No",
    "GPS Required": e.location_required ? "Yes" : "No",
    "Latitude": e.location_lat ?? "",
    "Longitude": e.location_lng ?? "",
    "Radius (m)": e.location_radius_m ?? "",
    "Scheduled Start": e.scheduled_start_at ? new Date(e.scheduled_start_at).toLocaleString() : "",
    "Scheduled End": e.scheduled_end_at ? new Date(e.scheduled_end_at).toLocaleString() : "",
  }));

  const exportExamsExcel = () => {
    const rows = buildExamRows();
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [{ wch: 4 }, { wch: 28 }, { wch: 32 }, { wch: 12 }, { wch: 10 }, { wch: 9 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 10 }, { wch: 20 }, { wch: 20 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Exams");
    XLSX.writeFile(wb, `IS_STUDY_MUM_Exams_${new Date().toISOString().slice(0, 10)}.xlsx`);
    toast.success("XLSX imeshushwa");
  };

  const exportExamsPDF = () => {
    const doc = new jsPDF({ orientation: "landscape" });
    doc.setFontSize(16); doc.setFont("helvetica", "bold");
    doc.text("ISLAMIC STUDIES MUM — Exams Report", 14, 15);
    doc.setFontSize(10); doc.setFont("helvetica", "normal");
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 22);
    doc.text(`Total exams: ${exams.length}`, 14, 28);
    autoTable(doc, {
      startY: 34,
      head: [["#", "Title", "Duration", "Status", "GPS", "Scheduled Start", "Scheduled End"]],
      body: exams.map((e, i) => [
        i + 1, e.title, formatHMS(e.duration_seconds),
        e.is_active ? "Active" : "Inactive",
        e.location_required ? "Yes" : "No",
        e.scheduled_start_at ? new Date(e.scheduled_start_at).toLocaleString() : "—",
        e.scheduled_end_at ? new Date(e.scheduled_end_at).toLocaleString() : "—",
      ]),
      styles: { fontSize: 9, cellPadding: 2 },
      headStyles: { fillColor: [15, 35, 70], textColor: 255, fontStyle: "bold" },
      alternateRowStyles: { fillColor: [245, 247, 250] },
    });
    doc.save(`IS_STUDY_MUM_Exams_${new Date().toISOString().slice(0, 10)}.pdf`);
    toast.success("PDF imeshushwa");
  };


  if (!admin) return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-gradient-hero text-primary-foreground sticky top-0 z-40 shadow-elegant">
        <div className="container py-3 flex items-center justify-between gap-3 flex-wrap">
          <BrandLockup variant="dark" subtitle="Admin Panel" />
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <div className="hidden md:flex items-center gap-2">
              <LanguageToggle />
            </div>
            <Button asChild variant="secondary" size="sm" className="h-8">
              <Link to="/admin/semesters"><Users className="h-4 w-4 mr-1" /> <span>Seminars</span></Link>
            </Button>
            <Button asChild variant="secondary" size="sm" className="h-8">
              <Link to="/admin/seminar-browser"><Users className="h-4 w-4 mr-1" /> <span>Browser</span></Link>
            </Button>
            <Button asChild variant="secondary" size="sm" className="h-8">
              <Link to="/admin/edit-requests"><Inbox className="h-4 w-4 mr-1" /> <span>Edit Reqs</span></Link>
            </Button>
            <Button asChild variant="secondary" size="sm" className="h-8">
              <Link to="/admin/seminar-questions"><FileText className="h-4 w-4 mr-1" /> <span>Papers</span></Link>
            </Button>
            <Button asChild variant="secondary" size="sm" className="h-8">
              <Link to="/admin/submissions"><Inbox className="h-4 w-4 mr-1" /> <span>Submissions</span></Link>
            </Button>
            <Button asChild variant="secondary" size="sm" className="h-8">
              <Link to="/admin/attendance"><CalendarClock className="h-4 w-4 mr-1" /> <span>Attendance</span></Link>
            </Button>
            <Button asChild variant="secondary" size="sm" className="h-8">
              <Link to="/admin/announcements"><Megaphone className="h-4 w-4 mr-1" /> <span>News</span></Link>
            </Button>
            <Button
              variant={systemLocked ? "destructive" : "secondary"}
              size="sm"
              onClick={quickToggleLock}
              className="h-8"
              title={systemLocked ? "Mfumo umefungwa kwa wanafunzi — bofya kufungua" : "Funga mfumo kwa wanafunzi"}
            >
              {systemLocked ? <Lock className="h-4 w-4 mr-1" /> : <Unlock className="h-4 w-4 mr-1" />}
              <span>{systemLocked ? "Locked" : "Lock"}</span>
            </Button>
            <Button variant="secondary" size="sm" onClick={openHome} className="h-8">
              <Home className="h-4 w-4 mr-1" /> <span>Settings</span>
            </Button>
            <Button variant="secondary" size="sm" onClick={() => setShowPwd((s) => !s)} className="h-8">
              <KeyRound className="h-4 w-4 mr-1" /> <span>Password</span>
            </Button>
            <div className="hidden lg:flex items-center gap-1.5 text-xs px-2 py-1 rounded-full bg-primary-foreground/15">
              <Shield className="h-3.5 w-3.5 text-accent-glow" /> {admin.username}
            </div>
            <Button variant="ghost" size="sm" onClick={logout} className="h-8 text-primary-foreground hover:bg-primary-foreground/15 hover:text-primary-foreground">
              <LogOut className="h-4 w-4 mr-1" /> <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-extrabold">Exams</h1>
            <p className="text-sm text-muted-foreground">Create and manage your exams.</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={exportExamsExcel} disabled={exams.length === 0}>
              <FileSpreadsheet className="h-4 w-4 mr-1" /> Export XLSX
            </Button>
            <Button variant="outline" size="sm" onClick={exportExamsPDF} disabled={exams.length === 0}>
              <FileDown className="h-4 w-4 mr-1" /> Export PDF
            </Button>
            <Button onClick={openCreate}><Plus className="h-4 w-4 mr-1" /> New Exam</Button>
          </div>
        </div>

        {showPwd && (
          <Card className="p-6 mb-6 shadow-card border-accent/30">
            <div className="flex items-center gap-2 mb-4">
              <KeyRound className="h-5 w-5 text-accent" />
              <h2 className="font-bold">Change Admin Password</h2>
            </div>
            <form onSubmit={submitPwd} className="grid sm:grid-cols-3 gap-3">
              <div>
                <Label>Current Password</Label>
                <Input type="password" value={curPwd} onChange={(e) => setCurPwd(e.target.value)} required autoComplete="current-password" />
              </div>
              <div>
                <Label>New Password</Label>
                <Input type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} required minLength={6} autoComplete="new-password" />
              </div>
              <div>
                <Label>Confirm New Password</Label>
                <Input type="password" value={newPwd2} onChange={(e) => setNewPwd2(e.target.value)} required minLength={6} autoComplete="new-password" />
              </div>
              <div className="sm:col-span-3 flex gap-2">
                <Button type="submit" disabled={pwdLoading}>
                  {pwdLoading ? (<><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Saving...</>) : (<><KeyRound className="h-4 w-4 mr-1" /> Update Password</>)}
                </Button>
                <Button type="button" variant="ghost" onClick={() => setShowPwd(false)}>Cancel</Button>
              </div>
            </form>
            <div className="border-t mt-4 pt-4">
              <h3 className="font-bold text-sm mb-2 flex items-center gap-2"><Shield className="h-4 w-4 text-accent" /> Badilisha Username</h3>
              <form onSubmit={submitUsername} className="grid sm:grid-cols-3 gap-3">
                <div><Label className="text-xs">Username Mpya</Label>
                  <Input value={newUsername} onChange={(e) => setNewUsername(e.target.value)} placeholder="mfano: admin" /></div>
                <div><Label className="text-xs">Password ya sasa</Label>
                  <Input type="password" value={curPwd} onChange={(e) => setCurPwd(e.target.value)} /></div>
                <div className="flex items-end">
                  <Button type="submit" disabled={usrLoading} variant="outline" className="w-full">{usrLoading ? "..." : "Badilisha"}</Button>
                </div>
              </form>
            </div>
          </Card>
        )}

        {showHome && (
          <Card className="p-6 mb-6 shadow-card border-accent/30">
            <div className="flex items-center gap-2 mb-4">
              <Home className="h-5 w-5 text-accent" />
              <h2 className="font-bold">Home Page & System Settings</h2>
            </div>
            <form onSubmit={saveHome} className="grid gap-4">
              {/* System lock */}
              <div className="rounded-lg border border-border p-4 bg-muted/30">
                <div className="flex items-center justify-between gap-3 mb-2">
                  <Label className="cursor-pointer flex items-center gap-2">
                    {systemLocked ? <Lock className="h-4 w-4 text-destructive" /> : <Unlock className="h-4 w-4 text-accent" />}
                    Lock System (block students from using the site)
                  </Label>
                  <UISwitch checked={systemLocked} onCheckedChange={setSystemLocked} />
                </div>
                <p className="text-xs text-muted-foreground mb-2">
                  When ON: students cannot open the home page, register, take exams or submit work. The admin panel is unaffected.
                </p>
                <Label className="text-xs">Message shown to students when locked</Label>
                <Textarea value={lockMessage} onChange={(e) => setLockMessage(e.target.value)} rows={2} placeholder="Mfumo umefungwa kwa muda na admin. Tafadhali subiri." />
              </div>

              {/* Admin contacts */}
              <div className="rounded-lg border border-border p-4 bg-muted/30">
                <Label className="font-semibold mb-2 block">Admin Contact (shown in footer + lock screen)</Label>
                <div className="grid sm:grid-cols-3 gap-3">
                  <div>
                    <Label className="text-xs">Email</Label>
                    <Input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} placeholder="admin@example.com" />
                  </div>
                  <div>
                    <Label className="text-xs">Phone</Label>
                    <Input type="tel" value={adminPhone} onChange={(e) => setAdminPhone(e.target.value)} placeholder="+255 7XX XXX XXX" className="font-mono-num" />
                  </div>
                  <div>
                    <Label className="text-xs">WhatsApp</Label>
                    <Input type="tel" value={adminWhatsapp} onChange={(e) => setAdminWhatsapp(e.target.value)} placeholder="+255 7XX XXX XXX" className="font-mono-num" />
                  </div>
                </div>
              </div>

              <p className="text-xs text-muted-foreground">Edit the text shown on the public home page. Leave a field empty to hide it.</p>

              {/* Banner image upload */}
              <div className="rounded-lg border border-accent/30 p-4 bg-accent/5">
                <Label className="font-semibold mb-2 block">Picha ya Banner (Home page)</Label>
                <p className="text-xs text-muted-foreground mb-3">Pakia picha kubwa itakayoonekana juu ya banner kwenye home page. (JPG/PNG/WebP, max 8MB)</p>
                {bannerImageUrl && (
                  <div className="mb-3 rounded-lg overflow-hidden border border-border bg-card">
                    <img src={bannerImageUrl} alt="Banner preview" className="w-full max-h-48 object-cover" />
                  </div>
                )}
                <div className="flex gap-2 items-center flex-wrap">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => onBannerFile(e.target.files?.[0] || null)}
                    disabled={bannerUploading}
                    className="max-w-xs"
                  />
                  {bannerUploading && <span className="text-xs text-muted-foreground"><Loader2 className="h-3 w-3 inline animate-spin mr-1" />Inapakia…</span>}
                  {bannerImageUrl && (
                    <Button type="button" size="sm" variant="outline" onClick={removeBanner}>Ondoa Picha</Button>
                  )}
                </div>
              </div>

              <div>
                <Label>Hero Title (large heading)</Label>
                <Input value={heroTitle} onChange={(e) => setHeroTitle(e.target.value)} placeholder="Islamic Study Test Online" />
              </div>
              <div>
                <Label>Hero Subtitle / Badge (small line above title)</Label>
                <Input value={heroSubtitle} onChange={(e) => setHeroSubtitle(e.target.value)} placeholder="e.g. Secure Examination Platform — leave empty to hide" />
              </div>
              <div>
                <Label>Message when no exam is scheduled</Label>
                <Textarea value={emptyMsg} onChange={(e) => setEmptyMsg(e.target.value)} rows={2} placeholder="Leave empty to hide this message completely" />
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={homeLoading}>
                  {homeLoading ? (<><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Saving...</>) : "Save All Settings"}
                </Button>
                <Button type="button" variant="ghost" onClick={() => setShowHome(false)}>Close</Button>
              </div>
            </form>
          </Card>
        )}

        {showForm && (
          <Card className="p-6 mb-6 shadow-card">
            <h2 className="font-bold mb-4">{editing ? "Edit Exam" : "New Exam"}</h2>
            <form onSubmit={saveExam} className="space-y-4">
              <div>
                <Label>Title</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} required />
              </div>
              <div>
                <Label>Description (optional)</Label>
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
              </div>
              <div>
                <Label>Exam Duration</Label>
                <div className="grid grid-cols-3 gap-3 mt-1">
                  <div><Label className="text-xs text-muted-foreground">Hours</Label>
                    <Input type="number" min={0} max={23} value={hours} onChange={(e) => setHours(+e.target.value || 0)} className="font-mono-num" /></div>
                  <div><Label className="text-xs text-muted-foreground">Minutes</Label>
                    <Input type="number" min={0} max={59} value={minutes} onChange={(e) => setMinutes(+e.target.value || 0)} className="font-mono-num" /></div>
                  <div><Label className="text-xs text-muted-foreground">Seconds</Label>
                    <Input type="number" min={0} max={59} value={seconds} onChange={(e) => setSeconds(+e.target.value || 0)} className="font-mono-num" /></div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Total: <span className="font-mono-num font-bold">{formatHMS(hours*3600+minutes*60+seconds)}</span>
                </p>
              </div>

              <div>
                <Label className="flex items-center gap-2"><CalendarClock className="h-4 w-4 text-accent" /> Start Date (optional — countdown shown on home page)</Label>
                <Input type="datetime-local" value={scheduledStart} onChange={(e) => setScheduledStart(e.target.value)} className="font-mono-num" />
              </div>

              <div>
                <Label className="flex items-center gap-2"><CalendarClock className="h-4 w-4 text-destructive" /> End Date / Deadline (optional — mtihani utajisubmit automatic ukifika)</Label>
                <Input type="datetime-local" value={scheduledEnd} onChange={(e) => setScheduledEnd(e.target.value)} className="font-mono-num" />
                <p className="text-xs text-muted-foreground mt-1">Mwanafunzi akishindwa kuwasilisha kabla ya muda huu, mfumo utawasilisha jibu lake otomatiki.</p>
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Switch checked={active} onCheckedChange={setActive} id="act" />
                  <Label htmlFor="act" className="cursor-pointer">Active</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={shuffleQ} onCheckedChange={setShuffleQ} id="sh" />
                  <Label htmlFor="sh" className="cursor-pointer">Shuffle Questions</Label>
                </div>
              </div>

              <div className="rounded-lg border border-border p-4 space-y-3 bg-muted/30">
                <div className="flex items-center justify-between gap-3">
                  <Label htmlFor="loc" className="cursor-pointer flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-accent" /> Require GPS Location
                  </Label>
                  <Switch id="loc" checked={locationRequired} onCheckedChange={setLocationRequired} />
                </div>
                {locationRequired && (
                  <>
                    <p className="text-xs text-muted-foreground">
                      Students can only take this exam when within the radius of the chosen location.
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs text-muted-foreground">Latitude</Label>
                        <Input value={locLat} onChange={(e) => setLocLat(e.target.value)} placeholder="-6.792354" className="font-mono-num" />
                      </div>
                      <div>
                        <Label className="text-xs text-muted-foreground">Longitude</Label>
                        <Input value={locLng} onChange={(e) => setLocLng(e.target.value)} placeholder="39.208328" className="font-mono-num" />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Allowed Radius (meters)</Label>
                      <Input type="number" min={50} max={5000} value={locRadius} onChange={(e) => setLocRadius(+e.target.value || 200)} className="font-mono-num" />
                    </div>
                    <Button type="button" variant="outline" size="sm" onClick={useMyLocation}>
                      <Crosshair className="h-4 w-4 mr-1" /> Use My Location
                    </Button>
                  </>
                )}
              </div>

              <div className="flex gap-2">
                <Button type="submit">{editing ? "Update" : "Create"}</Button>
                <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Close</Button>
              </div>
            </form>
          </Card>
        )}

        {exams.length === 0 && !showForm && (
          <Card className="p-12 text-center text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-3 opacity-40" />
            No exams yet. Click "New Exam" to start.
          </Card>
        )}

        <div className="grid md:grid-cols-2 gap-4">
          {exams.map((e) => (
            <Card key={e.id} className="p-5 shadow-card hover:shadow-elegant transition-smooth">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="min-w-0">
                  <h3 className="font-bold truncate">{e.title}</h3>
                  {e.description && <p className="text-sm text-muted-foreground line-clamp-2">{e.description}</p>}
                </div>
                <span className={`shrink-0 text-[10px] uppercase tracking-widest px-2 py-1 rounded-full ${
                  e.is_active ? "bg-accent/10 text-accent" : "bg-muted text-muted-foreground"
                }`}>{e.is_active ? "Active" : "Inactive"}</span>
              </div>
              <div className="text-sm text-muted-foreground mb-4">
                Duration: <span className="font-mono-num font-semibold text-foreground">{formatHMS(e.duration_seconds)}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button asChild size="sm" variant="outline">
                  <Link to={`/admin/exams/${e.id}/questions`}><FileText className="h-3.5 w-3.5 mr-1" /> Questions</Link>
                </Button>
                <Button asChild size="sm" variant="outline">
                  <Link to={`/admin/exams/${e.id}/results`}><Users className="h-3.5 w-3.5 mr-1" /> Results</Link>
                </Button>
                <Button size="sm" variant="ghost" onClick={() => openEdit(e)}><Edit className="h-3.5 w-3.5" /></Button>
                <Button size="sm" variant="ghost" onClick={() => deleteExam(e.id)} className="text-destructive hover:text-destructive">
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
