// @ts-nocheck
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2, Edit, ListChecks } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";

type QType = "mcq" | "true_false" | "short_answer" | "long_answer";

interface Question {
  id: string; question_text: string; question_type: QType;
  options: string[] | null; correct_answer: string; marks: number; position: number;
}

const TYPE_LABELS: Record<QType, string> = {
  mcq: "MCQ",
  true_false: "Kweli/Sio Kweli",
  short_answer: "Jibu Fupi",
  long_answer: "Jibu Refu (Insha)",
};

const AdminQuestions = () => {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState<any>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Question | null>(null);

  const [type, setType] = useState<QType>("mcq");
  const [text, setText] = useState("");
  const [options, setOptions] = useState<string[]>(["", "", "", ""]);
  const [correctIdx, setCorrectIdx] = useState(0);
  const [shortCorrect, setShortCorrect] = useState("");
  const [marks, setMarks] = useState(1);

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, [examId]);

  const load = async () => {
    const { data: ex } = await supabase.from("exams").select("*").eq("id", examId).single();
    setExam(ex);
    const { data: qs } = await supabase.from("questions").select("*").eq("exam_id", examId).order("position");
    setQuestions((qs as any) || []);
  };

  const openCreate = () => {
    setEditing(null);
    setType("mcq"); setText(""); setOptions(["", "", "", ""]);
    setCorrectIdx(0); setShortCorrect(""); setMarks(1);
    setShowForm(true);
  };

  const openEdit = (q: Question) => {
    setEditing(q);
    setType(q.question_type); setText(q.question_text); setMarks(q.marks);
    if (q.question_type === "mcq" && q.options) {
      setOptions([...q.options, "", "", "", ""].slice(0, Math.max(4, q.options.length)));
      setCorrectIdx(Math.max(0, q.options.indexOf(q.correct_answer)));
    } else if (q.question_type === "true_false") {
      setShortCorrect(q.correct_answer === "True" ? "true" : "false");
    } else {
      setShortCorrect(q.correct_answer);
    }
    setShowForm(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    let payload: any = {
      exam_id: examId, question_text: text, question_type: type, marks,
      position: editing?.position ?? questions.length,
    };
    if (type === "mcq") {
      const cleaned = options.map((o) => o.trim()).filter(Boolean);
      if (cleaned.length < 2) return toast.error("Weka angalau chaguo 2.");
      const correct = options[correctIdx]?.trim();
      if (!correct) return toast.error("Chagua jibu sahihi.");
      payload.options = cleaned;
      payload.correct_answer = correct;
    } else if (type === "true_false") {
      const v = (shortCorrect || "").trim().toLowerCase();
      if (v !== "true" && v !== "false") return toast.error("Chagua True au False.");
      payload.options = ["True", "False"];
      payload.correct_answer = v === "true" ? "True" : "False";
    } else if (type === "short_answer") {
      if (!shortCorrect.trim()) return toast.error("Weka jibu sahihi.");
      payload.options = null;
      payload.correct_answer = shortCorrect.trim();
    } else {
      // long_answer: graded manually by admin, no auto-correct
      payload.options = null;
      payload.correct_answer = shortCorrect.trim() || "[Manual grading]";
    }

    if (editing) {
      const { error } = await supabase.from("questions").update(payload).eq("id", editing.id);
      if (error) return toast.error(error.message);
      toast.success("Swali limesasishwa");
    } else {
      const { error } = await supabase.from("questions").insert(payload);
      if (error) return toast.error(error.message);
      toast.success("Swali limeongezwa");
    }
    setShowForm(false);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Futa swali hili?")) return;
    await supabase.from("questions").delete().eq("id", id);
    load();
  };

  if (!exam) return null;

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Mitihani
        </Link>
        <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-extrabold">{exam.title}</h1>
            <p className="text-sm text-muted-foreground">{questions.length} maswali</p>
          </div>
          <Button onClick={openCreate}><Plus className="h-4 w-4 mr-1" /> Swali Jipya</Button>
        </div>

        {showForm && (
          <Card className="p-6 mb-6 shadow-card">
            <h2 className="font-bold mb-4">{editing ? "Hariri Swali" : "Swali Jipya"}</h2>
            <form onSubmit={save} className="space-y-4">
              <div>
                <Label>Aina ya Swali</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  <Button type="button" size="sm" variant={type === "mcq" ? "default" : "outline"} onClick={() => setType("mcq")}>Multiple Choice</Button>
                  <Button type="button" size="sm" variant={type === "true_false" ? "default" : "outline"} onClick={() => setType("true_false")}>Kweli/Sio Kweli</Button>
                  <Button type="button" size="sm" variant={type === "short_answer" ? "default" : "outline"} onClick={() => setType("short_answer")}>Jibu Fupi</Button>
                  <Button type="button" size="sm" variant={type === "long_answer" ? "default" : "outline"} onClick={() => setType("long_answer")}>Jibu Refu (Insha)</Button>
                </div>
              </div>
              <div>
                <Label>Swali</Label>
                <Textarea value={text} onChange={(e) => setText(e.target.value)} required rows={2} />
              </div>

              {type === "mcq" && (
                <div>
                  <Label>Chaguo (chagua jibu sahihi)</Label>
                  <div className="space-y-2 mt-1">
                    {options.map((opt, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <input type="radio" name="correct" checked={correctIdx === i} onChange={() => setCorrectIdx(i)} className="h-4 w-4" />
                        <span className="font-bold w-5 text-sm">{String.fromCharCode(65 + i)}.</span>
                        <Input value={opt} onChange={(e) => { const a = [...options]; a[i] = e.target.value; setOptions(a); }} placeholder={`Chaguo ${i + 1}`} />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {type === "true_false" && (
                <div>
                  <Label>Jibu Sahihi</Label>
                  <div className="flex gap-2 mt-1">
                    <Button type="button" size="sm" variant={shortCorrect === "true" ? "default" : "outline"} onClick={() => setShortCorrect("true")}>True (Kweli)</Button>
                    <Button type="button" size="sm" variant={shortCorrect === "false" ? "default" : "outline"} onClick={() => setShortCorrect("false")}>False (Sio Kweli)</Button>
                  </div>
                </div>
              )}

              {type === "short_answer" && (
                <div>
                  <Label>Jibu Sahihi</Label>
                  <Input value={shortCorrect} onChange={(e) => setShortCorrect(e.target.value)} placeholder="Jibu kamili" />
                  <p className="text-xs text-muted-foreground mt-1">Linganishwa kwa case-insensitive.</p>
                </div>
              )}

              {type === "long_answer" && (
                <div>
                  <Label>Mwongozo wa Jibu (kwa admin pekee)</Label>
                  <Textarea value={shortCorrect} onChange={(e) => setShortCorrect(e.target.value)} rows={3} placeholder="Andika mfano wa jibu sahihi/maeneo muhimu ya kuangalia..." />
                  <p className="text-xs text-warning mt-1">⚠ Maswali ya insha hupimwa <strong>kwa mkono</strong> na admin baada ya kuwasilishwa.</p>
                </div>
              )}

              <div>
                <Label>Alama</Label>
                <Input type="number" min={1} value={marks} onChange={(e) => setMarks(+e.target.value || 1)} className="font-mono-num w-24" />
              </div>

              <div className="flex gap-2">
                <Button type="submit">{editing ? "Sasisha" : "Ongeza"}</Button>
                <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Funga</Button>
              </div>
            </form>
          </Card>
        )}

        {questions.length === 0 && !showForm && (
          <Card className="p-12 text-center text-muted-foreground">
            <ListChecks className="h-12 w-12 mx-auto mb-3 opacity-40" />
            Bado hakuna maswali. Bonyeza "Swali Jipya" kuanza.
          </Card>
        )}

        <div className="space-y-3">
          {questions.map((q, i) => (
            <Card key={q.id} className="p-5 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2 flex-wrap">
                    <span className="px-2 py-0.5 rounded-full bg-primary/5 text-primary font-semibold">#{i + 1}</span>
                    <span className="px-2 py-0.5 rounded-full bg-muted">{TYPE_LABELS[q.question_type]}</span>
                    <span>Alama: {q.marks}</span>
                  </div>
                  <p className="font-semibold mb-2">{q.question_text}</p>
                  {q.question_type === "mcq" && q.options && (
                    <ul className="text-sm space-y-1">
                      {q.options.map((o, idx) => (
                        <li key={idx} className={o === q.correct_answer ? "text-accent font-semibold" : "text-muted-foreground"}>
                          {String.fromCharCode(65 + idx)}. {o} {o === q.correct_answer && "✓"}
                        </li>
                      ))}
                    </ul>
                  )}
                  {q.question_type === "short_answer" && (
                    <p className="text-sm text-accent font-semibold">Jibu: {q.correct_answer}</p>
                  )}
                  {q.question_type === "long_answer" && (
                    <p className="text-sm text-warning">Hupimwa kwa mkono na admin</p>
                  )}
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => openEdit(q)}><Edit className="h-3.5 w-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(q.id)} className="text-destructive hover:text-destructive">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminQuestions;
