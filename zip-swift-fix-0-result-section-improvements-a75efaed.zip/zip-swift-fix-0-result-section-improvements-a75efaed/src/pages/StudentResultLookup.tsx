import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap, Search, Trophy, AlertCircle, Home, Download, FileSpreadsheet, FileText, ShieldCheck, Ban, Edit3, Sparkles, Send, Clock, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { exportRowsToCSV, exportResultsToPDF } from "@/lib/exportResults";
import BrandLockup from "@/components/BrandLockup";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

interface ResultItem {
  id: string;
  exam_id: string;
  exam_title: string;
  score: number | null;
  total: number | null;
  status: string;
  submitted_at: string | null;
  published: boolean;
  show_answers: boolean;
}

interface RevQ {
  id: string;
  question_text: string;
  question_type: string;
  options: any;
  correct_answer: string | null;
  marks: number;
  student_answer: string | null;
  awarded: number | null;
}

const StudentResultLookup = () => {
  const [examNumber, setExamNumber] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ResultItem[] | null>(null);
  const [studentName, setStudentName] = useState("");
  const [studentCourse, setStudentCourse] = useState<string>("");
  const [examNumberSaved, setExamNumberSaved] = useState("");
  const [revOpen, setRevOpen] = useState<Record<string, boolean>>({});
  const [revData, setRevData] = useState<Record<string, RevQ[]>>({});
  const [revLoading, setRevLoading] = useState<Record<string, boolean>>({});

  // --- Verify-and-add (push to exam_marks) state ---
  const [exams, setExams] = useState<{ id: string; title: string }[]>([]);
  const [vReg, setVReg] = useState("");
  const [vExamId, setVExamId] = useState("");
  const [vField, setVField] = useState<"test1" | "test2" | "presentation" | "contribution">("test1");
  const [vLoading, setVLoading] = useState(false);

  // --- Edit-request state ---
  const [allowEdits, setAllowEdits] = useState(true);
  const [foundStudentId, setFoundStudentId] = useState<string | null>(null);
  const [foundScore, setFoundScore] = useState<{ score: number | null; total: number | null } | null>(null);
  const [reqOpen, setReqOpen] = useState(false);
  const [reqName, setReqName] = useState("");
  const [reqReg, setReqReg] = useState("");
  const [reqReason, setReqReason] = useState("");
  const [reqLoading, setReqLoading] = useState(false);
  const [myRequests, setMyRequests] = useState<any[]>([]);

  useEffect(() => {
    supabase
      .from("exams")
      .select("id, title")
      .order("title")
      .then(({ data }) => setExams((data as any) || []));
    supabase
      .from("home_settings" as any)
      .select("allow_student_edits")
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setAllowEdits((data as any).allow_student_edits ?? true);
      });
  }, []);

  const fieldLabels: Record<string, string> = {
    test1: "Test 1",
    test2: "Test 2",
    presentation: "Presentation",
    contribution: "Contribution / Attendance",
  };

  const verifyAndPush = async () => {
    const reg = vReg.trim().toUpperCase();
    if (!reg) return toast.error("Andika namba yako ya usajili.");
    if (!vExamId) return toast.error("Chagua mtihani.");
    setVLoading(true);
    try {
      const { data: student } = await supabase
        .from("students")
        .select("id, full_name, exam_number")
        .eq("exam_number", reg)
        .maybeSingle();
      if (!student) {
        toast.error("Namba hii haipo kwenye mfumo.");
        return;
      }

      const { data: attempt } = await supabase
        .from("attempts")
        .select("id, score, total_marks, status, violation_reason")
        .eq("student_id", student.id)
        .eq("exam_id", vExamId)
        .order("submitted_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (!attempt) {
        toast.error("Hujafanya mtihani huu.");
        return;
      }
      if (attempt.status === "terminated") {
        toast.error(`Ulidanganya — hutaweza kuingiza matokeo. ${attempt.violation_reason || ""}`);
        return;
      }
      if (attempt.score == null) {
        toast.error("Mtihani wako bado haujapata alama.");
        return;
      }

      const { data: existing } = await supabase
        .from("exam_marks" as any)
        .select("*")
        .eq("exam_id", vExamId)
        .ilike("reg_no", reg)
        .maybeSingle();

      const score = Number(attempt.score);
      if (existing) {
        const ex: any = existing;
        if (ex[vField] != null) {
          toast.info(`Tayari upo kwenye mfumo — ${fieldLabels[vField]} = ${ex[vField]}.`);
          return;
        }
        const { error } = await supabase
          .from("exam_marks" as any)
          .update({ [vField]: score, full_name: student.full_name, updated_at: new Date().toISOString() })
          .eq("id", ex.id);
        if (error) { toast.error(error.message); return; }
        toast.success(`Imehifadhiwa: ${fieldLabels[vField]} = ${score}.`);
      } else {
        const { error } = await supabase.from("exam_marks" as any).insert({
          exam_id: vExamId,
          full_name: student.full_name,
          reg_no: reg,
          [vField]: score,
        });
        if (error) { toast.error(error.message); return; }
        toast.success(`Imeingizwa kwenye Excel: ${fieldLabels[vField]} = ${score}.`);
      }
    } finally {
      setVLoading(false);
    }
  };

  const search = async (e: React.FormEvent) => {
    e.preventDefault();
    const raw = examNumber.trim();
    if (!raw) return;
    const num = raw.toUpperCase();
    setLoading(true);
    setResults(null);

    console.log("[v0] Search started with:", { raw, num });

    // Try Reg No first, then fall back to full name (ilike, case-insensitive).
    let student: any = null;
    const byReg = await supabase
      .from("students")
      .select("id, full_name, exam_number, course")
      .ilike("exam_number", num)
      .maybeSingle();
    
    console.log("[v0] Search by reg result:", byReg);
    
    student = byReg.data;
    if (!student) {
      const { data: byName, error: nameError } = await supabase
        .from("students")
        .select("id, full_name, exam_number, course")
        .ilike("full_name", `%${raw}%`)
        .limit(2);
      
      console.log("[v0] Search by name result:", { byName, nameError });
      
      const list = (byName as any[]) || [];
      if (list.length === 1) student = list[0];
      else if (list.length > 1) {
        setLoading(false);
        toast.error("Majina yamejirudia. Tumia Reg No kupata matokeo sahihi.");
        return;
      }
    }

    if (!student) {
      setLoading(false);
      console.log("[v0] No student found");
      toast.error("Taarifa hizi hazijapatikana. Hakikisha umeandika sahihi.");
      return;
    }
    
    console.log("[v0] Found student:", student);

    setStudentName(student.full_name);
    setStudentCourse(student.course || "");
    setExamNumberSaved(student.exam_number);
    setFoundStudentId(student.id);
    setReqName(student.full_name);
    setReqReg(student.exam_number);

    const { data: attempts, error: attemptsError } = await supabase
      .from("attempts")
      .select("id, exam_id, score, total_marks, status, submitted_at, exams(title, results_published)")
      .eq("student_id", student.id)
      .order("submitted_at", { ascending: false });

    console.log("[v0] Attempts query result:", { attempts, attemptsError, studentId: student.id });

    const items: ResultItem[] = (attempts || []).map((a: any) => ({
      id: a.id,
      exam_id: a.exam_id,
      exam_title: a.exams?.title || "—",
      score: a.score,
      total: a.total_marks,
      status: a.status,
      submitted_at: a.submitted_at,
      published: !!a.exams?.results_published,
      show_answers: !!a.exams?.results_published, // Show answers if results are published
    }));

    console.log("[v0] Processed items:", items);

    setResults(items);
    // top score for the snapshot
    const top = (attempts || []).reduce((acc: any, a: any) => (a.score != null ? a : acc), null);
    setFoundScore(top ? { score: top.score, total: top.total_marks } : null);
    // existing requests for this reg
    const { data: reqs } = await supabase
      .from("student_edit_requests" as any)
      .select("*")
      .ilike("submitted_reg_no", student.exam_number)
      .order("created_at", { ascending: false })
      .limit(10);
    setMyRequests((reqs as any) || []);
    setLoading(false);
  };

  const published = (results || []).filter((r) => r.published);

  const submitEditRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!allowEdits) return toast.error("Maombi yamefungwa kwa sasa.");
    const newName = reqName.trim();
    const newReg = reqReg.trim().toUpperCase();
    if (!newName || !newReg) return toast.error("Jaza jina na Reg No.");
    setReqLoading(true);
    try {
      const { error } = await supabase.from("student_edit_requests" as any).insert({
        student_id: foundStudentId,
        submitted_reg_no: examNumberSaved,
        submitted_full_name: studentName,
        current_full_name: studentName,
        current_reg_no: examNumberSaved,
        requested_full_name: newName,
        requested_reg_no: newReg,
        reason: reqReason.trim() || null,
        score_snapshot: foundScore?.score ?? null,
        total_snapshot: foundScore?.total ?? null,
      });
      if (error) throw error;
      toast.success("Ombi limewasilishwa. Subiri admin akiridhie.");
      setReqOpen(false);
      setReqReason("");
      // refresh list
      const { data: reqs } = await supabase
        .from("student_edit_requests" as any)
        .select("*")
        .ilike("submitted_reg_no", examNumberSaved)
        .order("created_at", { ascending: false })
        .limit(10);
      setMyRequests((reqs as any) || []);
    } catch (err: any) {
      toast.error(err.message || "Imeshindikana.");
    } finally {
      setReqLoading(false);
    }
  };

  const toggleRevision = async (item: ResultItem) => {
    const next = !revOpen[item.id];
    setRevOpen((m) => ({ ...m, [item.id]: next }));
    if (!next || revData[item.id]) return;
    setRevLoading((m) => ({ ...m, [item.id]: true }));
    try {
      const [qsRes, ansRes] = await Promise.all([
        supabase.from("questions")
          .select("id, question_text, question_type, options, correct_answer, marks, position")
          .eq("exam_id", item.exam_id)
          .order("position", { ascending: true }),
        supabase.from("answers")
          .select("question_id, answer_text, awarded_marks")
          .eq("attempt_id", item.id),
      ]);
      const ansMap = new Map<string, any>();
      ((ansRes.data as any[]) || []).forEach((x) => ansMap.set(x.question_id, x));
      const merged: RevQ[] = ((qsRes.data as any[]) || []).map((q) => ({
        ...q,
        student_answer: ansMap.get(q.id)?.answer_text ?? null,
        awarded: ansMap.get(q.id)?.awarded_marks ?? null,
      }));
      setRevData((m) => ({ ...m, [item.id]: merged }));
    } finally {
      setRevLoading((m) => ({ ...m, [item.id]: false }));
    }
  };

  const downloadCSV = () => {
    if (!published.length) return toast.error("Hakuna matokeo yaliyochapishwa.");
    const headers = ["#", "Jina", "Namba", "Kozi", "Mtihani", "Alama", "Jumla", "Asilimia", "Hali", "Muda"];
    const rows = published.map((r, i) => {
      const pct = r.total && r.total > 0 ? Math.round(((r.score || 0) / r.total) * 100) + "%" : "—";
      return [i + 1, studentName, examNumberSaved, studentCourse || "—", r.exam_title, r.score ?? 0, r.total ?? 0, pct, r.status.replace("_", " "), r.submitted_at ? new Date(r.submitted_at).toLocaleString() : "—"];
    });
    exportRowsToCSV(`Matokeo_${examNumberSaved}.csv`, headers, rows);
  };

  const downloadExcel = () => {
    if (!published.length) return toast.error("Hakuna matokeo yaliyochapishwa.");
    const data = published.map((r, i) => ({
      "#": i + 1,
      "Jina": studentName,
      "Namba": examNumberSaved,
      "Kozi": studentCourse || "—",
      "Mtihani": r.exam_title,
      "Alama": r.score ?? 0,
      "Jumla": r.total ?? 0,
      "Asilimia": r.total && r.total > 0 ? Math.round(((r.score || 0) / r.total) * 100) + "%" : "—",
      "Hali": r.status.replace("_", " "),
      "Muda": r.submitted_at ? new Date(r.submitted_at).toLocaleString() : "—",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Matokeo");
    XLSX.writeFile(wb, `Matokeo_${examNumberSaved}.xlsx`);
  };

  const downloadPDF = () => {
    if (!published.length) return toast.error("Hakuna matokeo yaliyochapishwa.");
    exportResultsToPDF(`${studentName} (${examNumberSaved})`, published.map((r) => ({
      full_name: studentName,
      exam_number: examNumberSaved,
      score: r.score,
      total_marks: r.total,
      status: r.status,
      submitted_at: r.submitted_at,
      violation_reason: null,
    })));
  };

  return (
    <div className="min-h-screen bg-gradient-results text-foreground scene-3d">
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container h-16 flex items-center justify-between">
          <BrandLockup subtitle="Angalia Matokeo" />
          <Button asChild size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold shadow-lg"><Link to="/"><Home className="h-4 w-4 mr-1" /> Nyumbani</Link></Button>
        </div>
      </header>

      <div className="container py-10 max-w-2xl">
        <div className="text-center mb-8 reveal-up">
          <div className="inline-flex h-16 w-16 rounded-2xl bg-accent/20 text-accent items-center justify-center mb-3 float-y shadow-glow">
            <Trophy className="h-8 w-8" />
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold mb-1 text-gradient-hero">Angalia Matokeo Yako</h1>
          <p className="text-muted-foreground text-sm">Andika namba yako ya usajili kuangalia matokeo yako.</p>
        </div>

        {allowEdits && (
          <Card className="mb-6 p-4 border-accent/30 bg-card shadow-card reveal-up reveal-up-d1">
            <div className="flex items-start gap-3">
              <div className="h-10 w-10 rounded-xl bg-accent/15 text-accent grid place-items-center shrink-0">
                <Sparkles className="h-5 w-5" />
              </div>
              <div className="text-sm">
                <div className="font-extrabold mb-0.5 text-foreground">Mpya: Omba Marekebisho ya Taarifa Zako</div>
                <p className="text-xs text-muted-foreground">
                  Kama jina au Reg No yako iliingizwa vibaya, tafuta matokeo yako kisha bofya <b>"Omba Marekebisho"</b>. Admin akiridhia, taarifa zitabadilika moja kwa moja.
                </p>
              </div>
            </div>
          </Card>
        )}

        <Card className="p-6 mb-6 bg-card shadow-elegant border border-border rounded-2xl reveal-up reveal-up-d2 card-3d">

          <form onSubmit={search} className="space-y-4">
            <div>
              <Label className="text-foreground">Namba ya Usajili au Jina Kamili</Label>
              <Input
                value={examNumber}
                onChange={(e) => setExamNumber(e.target.value)}
                placeholder="MUM2021-04-08738 au John Doe"
                className="font-mono-num text-lg bg-white text-foreground"
                required
              />
            </div>
            <Button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
              <Search className="h-4 w-4 mr-2" /> {loading ? "Inatafuta..." : "Tafuta Matokeo"}
            </Button>
          </form>
        </Card>

        {results && (
          <div>
            <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
              <div className="text-sm text-muted-foreground space-y-1">
                <div>Mwanafunzi: <span className="font-bold text-foreground">{studentName}</span></div>
                <div className="flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-bold uppercase tracking-widest">
                    <GraduationCap className="h-3 w-3" /> {examNumberSaved}
                  </span>
                  {studentCourse && (
                    <span className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-accent/10 text-accent font-bold uppercase tracking-widest">
                      Kozi: {studentCourse}
                    </span>
                  )}
                </div>
              </div>
              {published.length > 0 && (
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="bg-card text-foreground border-border" onClick={downloadCSV}>
                    <Download className="h-4 w-4 mr-1" /> CSV
                  </Button>
                  <Button size="sm" variant="outline" className="bg-card text-foreground border-border" onClick={downloadExcel}>
                    <FileSpreadsheet className="h-4 w-4 mr-1" /> Excel
                  </Button>
                  <Button size="sm" variant="outline" className="bg-card text-foreground border-border" onClick={downloadPDF}>
                    <FileText className="h-4 w-4 mr-1" /> PDF
                  </Button>
                </div>
              )}
            </div>
            {/* Edit request CTA + status */}
            {results.length > 0 && (
              <Card className="mb-3 p-4 border-accent/30 bg-card shadow-card">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2 text-sm text-foreground">
                    <Edit3 className="h-4 w-4 text-accent" />
                    <span>Taarifa zako zimekosewa? <b>Omba marekebisho</b> hapa.</span>
                  </div>
                  {allowEdits ? (
                    <Button size="sm" className="bg-primary text-primary-foreground" onClick={() => setReqOpen((v) => !v)}>
                      <Edit3 className="h-3.5 w-3.5 mr-1" /> {reqOpen ? "Funga" : "Omba Marekebisho"}
                    </Button>
                  ) : (
                    <span className="text-xs text-muted-foreground">Maombi yamefungwa kwa sasa.</span>
                  )}
                </div>
                {reqOpen && allowEdits && (
                  <form onSubmit={submitEditRequest} className="mt-3 grid gap-2">
                    <div className="grid sm:grid-cols-2 gap-2">
                      <div>
                        <Label className="text-xs text-foreground">Jina kamili sahihi</Label>
                        <Input value={reqName} onChange={(e) => setReqName(e.target.value)} className="bg-white text-foreground" required />
                      </div>
                      <div>
                        <Label className="text-xs text-foreground">Reg No sahihi</Label>
                        <Input value={reqReg} onChange={(e) => setReqReg(e.target.value.toUpperCase())} className="font-mono-num uppercase bg-white text-foreground" required />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs text-foreground">Sababu (hiari)</Label>
                      <Textarea rows={2} value={reqReason} onChange={(e) => setReqReason(e.target.value)} placeholder="Mfano: jina langu liliandikwa vibaya…" className="bg-white text-foreground" />
                    </div>
                    <Button type="submit" size="sm" className="bg-primary text-primary-foreground" disabled={reqLoading}>
                      <Send className="h-3.5 w-3.5 mr-1" /> {reqLoading ? "Inawasilisha…" : "Wasilisha Ombi"}
                    </Button>
                  </form>
                )}
                {myRequests.length > 0 && (
                  <div className="mt-3 space-y-1.5">
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Hali ya maombi yako</div>
                    {myRequests.map((r) => {
                      const Icon = r.status === "approved" ? CheckCircle2 : r.status === "rejected" ? XCircle : Clock;
                      const cls = r.status === "approved" ? "text-accent" : r.status === "rejected" ? "text-destructive" : "text-warning";
                      return (
                        <div key={r.id} className="flex items-center justify-between gap-2 text-xs p-2 rounded-md bg-muted/40">
                          <div className="flex items-center gap-2 min-w-0">
                            <Icon className={`h-3.5 w-3.5 ${cls}`} />
                            <span className="truncate">
                              <b>{r.requested_full_name}</b> · <span className="font-mono-num">{r.requested_reg_no}</span>
                            </span>
                          </div>
                          <span className={`uppercase tracking-widest font-bold ${cls}`}>{r.status}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>
            )}
            {results.length === 0 ? (
              <Card className="p-8 text-center text-muted-foreground">
                <AlertCircle className="h-10 w-10 mx-auto mb-2 opacity-40" />
                Hujafanya mtihani wowote bado.
              </Card>
            ) : (
              <div className="space-y-3">
                {results.map((r) => {
                  const pct = r.total && r.total > 0 ? Math.round(((r.score || 0) / r.total) * 100) : 0;
                  const passed = pct >= 50;
                  return (
                    <Card key={r.id} className="p-5 shadow-card bg-card">
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div className="min-w-0">
                          <h3 className="font-bold text-foreground">{r.exam_title}</h3>
                          <p className="text-xs text-muted-foreground">
                            {r.submitted_at ? new Date(r.submitted_at).toLocaleString() : "Hakijawasilishwa"}
                          </p>
                        </div>
                        {r.published ? (
                          <div className="text-right">
                            <div className="font-mono-num text-2xl font-extrabold text-primary">
                              {r.score ?? 0}<span className="text-base text-muted-foreground">/{r.total ?? 0}</span>
                            </div>
                            <div className={`text-sm font-bold ${passed ? "text-accent" : "text-destructive"}`}>
                              {pct}% — {passed ? "Umefaulu" : "Haukufaulu"}
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs px-3 py-1.5 rounded-full bg-warning/10 text-warning font-semibold uppercase tracking-widest">
                            Bado Hayajachapishwa
                          </span>
                        )}
                      </div>

                      {r.published && r.show_answers && (
                        <div className="mt-3 pt-3 border-t border-border">
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => toggleRevision(r)}
                            className="w-full sm:w-auto bg-card text-foreground border-border hover:bg-muted"
                          >
                            <Sparkles className="h-3.5 w-3.5 mr-1 text-accent" />
                            {revOpen[r.id] ? "Funga Revision" : "Pitia Majibu (Revision)"}
                          </Button>

                          {revOpen[r.id] && (
                            <div className="mt-3 space-y-2 reveal-up">
                              {revLoading[r.id] && (
                                <div className="text-sm text-muted-foreground">Inapakia majibu…</div>
                              )}
                              {revData[r.id]?.map((q, idx) => {
                                const correct = q.correct_answer || "";
                                const stu = q.student_answer || "";
                                const ok = q.awarded != null && q.awarded > 0;
                                const opts = Array.isArray(q.options) ? q.options : [];
                                return (
                                  <div key={q.id} className={`p-3 rounded-lg border-l-4 bg-muted/50 ${ok ? "border-l-accent" : "border-l-destructive"}`}>
                                    <div className="flex justify-between items-start gap-2 mb-1">
                                      <div className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Swali {idx + 1} · {q.marks} marks</div>
                                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${ok ? "bg-accent/15 text-accent" : "bg-destructive/15 text-destructive"}`}>
                                        {ok ? `+${q.awarded}` : "0"}
                                      </span>
                                    </div>
                                    <p className="text-sm font-semibold mb-2 text-foreground">{q.question_text}</p>
                                    {opts.length > 0 && (
                                      <div className="space-y-1 mb-2">
                                        {opts.map((o: string, i: number) => {
                                          const isC = String(o).toLowerCase() === correct.toLowerCase();
                                          const isS = String(o).toLowerCase() === stu.toLowerCase();
                                          return (
                                            <div key={i} className={`flex items-center gap-2 px-2 py-1 rounded text-xs ${isC ? "bg-accent/10 border border-accent/30" : isS ? "bg-destructive/10 border border-destructive/30" : "bg-card"}`}>
                                              {isC && <CheckCircle2 className="h-3 w-3 text-accent shrink-0" />}
                                              {isS && !isC && <XCircle className="h-3 w-3 text-destructive shrink-0" />}
                                              <span className={isC ? "font-bold text-accent" : isS ? "text-destructive line-through" : ""}>{o}</span>
                                            </div>
                                          );
                                        })}
                                      </div>
                                    )}
                                    <div className="grid sm:grid-cols-2 gap-2 text-xs">
                                      <div className="p-1.5 rounded bg-card border border-border">
                                        <div className="text-[9px] uppercase tracking-widest text-muted-foreground font-bold">Jibu lako</div>
                                        <div className={`font-semibold ${ok ? "text-accent" : "text-destructive"}`}>{stu || "—"}</div>
                                      </div>
                                      <div className="p-1.5 rounded bg-accent/5 border border-accent/30">
                                        <div className="text-[9px] uppercase tracking-widest text-accent font-bold">Jibu sahihi</div>
                                        <div className="font-semibold text-accent">{correct || "—"}</div>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                              {revData[r.id] && revData[r.id].length === 0 && (
                                <div className="text-sm text-muted-foreground">Hakuna maswali yaliyopatikana.</div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Verify & push to Excel */}
        <Card className="p-6 mt-8 shadow-card border-accent/30 bg-card">
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="h-5 w-5 text-accent" />
            <h2 className="font-extrabold text-foreground">Thibitisha Matokeo Yako</h2>
          </div>
          <p className="text-xs text-muted-foreground mb-4">
            Kama ulifanya mtihani lakini matokeo yako hayapo kwenye Excel/CSV, weka namba yako, chagua mtihani na aina ya assessment. Mfumo utathibitisha na kuingiza alama zako moja kwa moja.
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label className="text-foreground">Reg No (MUM...)</Label>
              <Input
                value={vReg}
                onChange={(e) => setVReg(e.target.value)}
                placeholder="MUM2021-04-08738"
                className="font-mono-num uppercase bg-white text-foreground"
              />
            </div>
            <div>
              <Label className="text-foreground">Mtihani</Label>
              <Select value={vExamId} onValueChange={setVExamId}>
                <SelectTrigger className="bg-white text-foreground"><SelectValue placeholder="Chagua mtihani" /></SelectTrigger>
                <SelectContent>
                  {exams.map((e) => (
                    <SelectItem key={e.id} value={e.id}>{e.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-foreground">Aina ya Assessment</Label>
              <Select value={vField} onValueChange={(v) => setVField(v as any)}>
                <SelectTrigger className="bg-white text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="test1">Test 1</SelectItem>
                  <SelectItem value="test2">Test 2</SelectItem>
                  <SelectItem value="presentation">Presentation</SelectItem>
                  <SelectItem value="contribution">Contribution / Attendance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={verifyAndPush} disabled={vLoading} className="w-full mt-4 bg-primary text-primary-foreground hover:bg-primary/90">
            <ShieldCheck className="h-4 w-4 mr-2" />
            {vLoading ? "Inathibitisha..." : "Thibitisha na Ingiza kwenye Excel"}
          </Button>
          <p className="text-[11px] text-muted-foreground mt-3 flex items-start gap-1">
            <Ban className="h-3 w-3 mt-0.5 text-destructive" />
            Ukidanganya mtihani, mfumo utakukatalia kuingiza matokeo.
          </p>
        </Card>
      </div>
    </div>
  );
};

export default StudentResultLookup;
