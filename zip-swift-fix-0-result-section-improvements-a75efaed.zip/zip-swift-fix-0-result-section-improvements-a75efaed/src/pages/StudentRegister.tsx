import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { GraduationCap, ArrowLeft, CheckCircle2 } from "lucide-react";

interface Exam { id: string; title: string; description: string | null; duration_seconds: number; scheduled_start_at: string | null; }

const REG_NO_REGEX = /^(MUM)?\d{4}-\d{2}-?\d{3,6}$/i;

const StudentRegister = () => {
  const navigate = useNavigate();
  const [regNo, setRegNo] = useState("");
  const [examId, setExamId] = useState<string>("");
  const [exams, setExams] = useState<Exam[]>([]);
  const [member, setMember] = useState<{ id: string; full_name: string; reg_no: string } | null>(null);
  const [lookingUp, setLookingUp] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.from("exams").select("id, title, description, duration_seconds, scheduled_start_at").eq("is_active", true).then(({ data }) => {
      setExams(data || []);
      if (data && data.length > 0) setExamId(data[0].id);
    });
  }, []);

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    const reg = regNo.trim().toUpperCase();
    if (!reg) return toast.error("Andika Reg No.");
    if (!REG_NO_REGEX.test(reg)) {
      return toast.error("Muundo wa Reg No si sahihi. Mifano: 2021-04-93392 au MUM2021-04578");
    }

    setLookingUp(true);
    try {
      // Block list check (table may not exist yet — ignore failure silently)
      try {
        const { data: blk } = await supabase
          .from("blocked_students" as any)
          .select("reason, full_name")
          .ilike("reg_no", reg)
          .maybeSingle();
        if (blk) {
          toast.error(`🚫 Umezuiwa kufanya mtihani${(blk as any).reason ? `: ${(blk as any).reason}` : "."}`);
          return;
        }
      } catch {}

      const { data } = await supabase
        .from("group_members")
        .select("id, full_name, reg_no")
        .ilike("reg_no", reg)
        .maybeSingle();

      if (!data) {
        toast.error("Reg No haijasajiliwa. Tafadhali jisajili kwanza kwenye semina.");
        return;
      }
      setMember(data);
      toast.success(`Karibu ${data.full_name}!`);
    } finally {
      setLookingUp(false);
    }
  };

  const handleStart = async () => {
    if (!member || !examId) return toast.error("Chagua mtihani.");
    const selectedExam = exams.find((x) => x.id === examId);
    if (selectedExam?.scheduled_start_at) {
      const startMs = new Date(selectedExam.scheduled_start_at).getTime();
      if (Date.now() < startMs) {
        const when = new Date(startMs).toLocaleString();
        toast.error(`Subiri muda ulioweka uanze mtihani. Mtihani utaanza ${when}.`);
        return;
      }
    }
    setLoading(true);
    try {
      let { data: existing } = await supabase
        .from("students")
        .select("id")
        .eq("exam_number", member.reg_no)
        .maybeSingle();

      let studentId = existing?.id;
      if (!studentId) {
        const { data: newS, error } = await supabase
          .from("students")
          .insert({ full_name: member.full_name, exam_number: member.reg_no })
          .select("id")
          .single();
        if (error) throw error;
        studentId = newS.id;
      }

      const { data: prev } = await supabase
        .from("attempts")
        .select("id, status")
        .eq("student_id", studentId)
        .eq("exam_id", examId)
        .maybeSingle();

      if (prev && prev.status !== "in_progress") {
        toast.error("Tayari umewasilisha mtihani huu.");
        setLoading(false);
        return;
      }

      sessionStorage.setItem("isStudyMum_student", JSON.stringify({
        studentId, examId, fullName: member.full_name, examNumber: member.reg_no
      }));
      navigate("/exam/instructions");
    } catch (err: any) {
      toast.error(err.message || "Hitilafu imetokea.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8">
          <ArrowLeft className="h-4 w-4" /> Rudi nyumbani
        </Link>

        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-hero items-center justify-center mb-4 text-primary-foreground shadow-elegant">
              <GraduationCap className="h-7 w-7" />
            </div>
            <h1 className="text-3xl font-extrabold mb-2">Ingia Kufanya Mtihani</h1>
            <p className="text-muted-foreground text-sm">Andika Reg No yako tu.</p>
          </div>

          <Card className="p-6 shadow-card">
            {!member ? (
              <form onSubmit={handleLookup} className="space-y-4">
                <div>
                  <Label htmlFor="reg">Reg No</Label>
                  <Input id="reg" value={regNo} onChange={(e) => setRegNo(e.target.value.toUpperCase())}
                    placeholder="MUM2021-04-06575 au 2021-04-07685" required className="font-mono-num" />
                  <p className="text-[11px] text-muted-foreground mt-1">
                    Lazima uwe umejisajiliwa tayari kwenye semina.
                  </p>
                </div>
                <Button type="submit" className="w-full" disabled={lookingUp}>
                  {lookingUp ? "Inatafuta..." : "Endelea"}
                </Button>
                <p className="text-xs text-center text-muted-foreground pt-2">
                  Hujajisajili?{" "}
                  <Link to="/exam/signup" className="text-accent font-semibold hover:underline">
                    Jisajili hapa
                  </Link>
                </p>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-accent/5 border border-accent/20">
                  <div className="flex items-center gap-2 mb-2 text-accent">
                    <CheckCircle2 className="h-4 w-4" />
                    <span className="text-xs uppercase tracking-widest font-semibold">Taarifa zako</span>
                  </div>
                  <div className="text-sm">
                    <div><span className="text-muted-foreground">Jina:</span> <strong>{member.full_name}</strong></div>
                    <div><span className="text-muted-foreground">Reg No:</span> <strong className="font-mono-num">{member.reg_no}</strong></div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="exam">Chagua mtihani</Label>
                  <select id="exam" value={examId} onChange={(e) => setExamId(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
                    {exams.length === 0 && <option value="">Hakuna mtihani uliopo sasa</option>}
                    {exams.map((ex) => (
                      <option key={ex.id} value={ex.id}>{ex.title}</option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => { setMember(null); setRegNo(""); }}>Badilisha</Button>
                  <Button className="flex-1" onClick={handleStart} disabled={loading || exams.length === 0}>
                    {loading ? "Inasubiri..." : "Endelea kufanya mtihani"}
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default StudentRegister;
