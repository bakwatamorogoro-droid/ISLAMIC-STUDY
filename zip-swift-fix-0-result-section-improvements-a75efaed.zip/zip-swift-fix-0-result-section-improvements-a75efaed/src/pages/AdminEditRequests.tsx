import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { ArrowLeft, CheckCircle2, XCircle, RefreshCw, Inbox, ShieldCheck } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";

interface ReqRow {
  id: string;
  student_id: string | null;
  submitted_reg_no: string;
  submitted_full_name: string | null;
  current_full_name: string | null;
  current_reg_no: string | null;
  requested_full_name: string;
  requested_reg_no: string;
  reason: string | null;
  score_snapshot: number | null;
  total_snapshot: number | null;
  status: "pending" | "approved" | "rejected" | string;
  admin_notes: string | null;
  created_at: string;
  reviewed_at: string | null;
}

const AdminEditRequests = () => {
  const navigate = useNavigate();
  const [rows, setRows] = useState<ReqRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<"pending" | "approved" | "rejected" | "all">("pending");
  const [allowEdits, setAllowEdits] = useState(true);
  const [homeId, setHomeId] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
      loadSettings();
    });
  }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("student_edit_requests" as any)
      .select("*")
      .order("created_at", { ascending: false })
      .limit(500);
    setRows((data as any) || []);
    setLoading(false);
  };

  const loadSettings = async () => {
    const { data } = await supabase
      .from("home_settings" as any)
      .select("id, allow_student_edits")
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (data) {
      setHomeId((data as any).id);
      setAllowEdits((data as any).allow_student_edits ?? true);
    }
  };

  const toggleAllow = async (val: boolean) => {
    setAllowEdits(val);
    if (homeId) {
      await supabase.from("home_settings" as any).update({ allow_student_edits: val, updated_at: new Date().toISOString() }).eq("id", homeId);
    } else {
      const { data } = await supabase.from("home_settings" as any).insert({ allow_student_edits: val }).select().single();
      if (data) setHomeId((data as any).id);
    }
    toast.success(val ? "Maombi yamewashwa." : "Maombi yamezimwa.");
  };

  const approve = async (r: ReqRow) => {
    const newName = r.requested_full_name.trim();
    const newReg = r.requested_reg_no.trim().toUpperCase();
    const oldReg = (r.current_reg_no || r.submitted_reg_no || "").toUpperCase().trim();
    if (!newName || !newReg) return toast.error("Maombi hayajakamilika.");
    try {
      // 1) update students by id (preferred) then fallback by old reg
      if (r.student_id) {
        await supabase.from("students").update({ full_name: newName, exam_number: newReg }).eq("id", r.student_id);
      } else if (oldReg) {
        await supabase.from("students").update({ full_name: newName, exam_number: newReg }).ilike("exam_number", oldReg);
      }
      // 2) cascade exam_marks
      if (oldReg) {
        await supabase.from("exam_marks" as any)
          .update({ reg_no: newReg, full_name: newName, updated_at: new Date().toISOString() })
          .ilike("reg_no", oldReg);
      }
      // 3) cascade group_members
      if (oldReg) {
        await supabase.from("group_members")
          .update({ reg_no: newReg, full_name: newName })
          .ilike("reg_no", oldReg);
      }
      // 4) mark request approved
      await supabase.from("student_edit_requests" as any).update({
        status: "approved",
        admin_notes: notes[r.id] || null,
        reviewed_at: new Date().toISOString(),
      }).eq("id", r.id);
      toast.success("Imeidhinishwa. Taarifa zimebadilishwa kila sehemu.");
      await load();
    } catch (e: any) {
      toast.error(e.message || "Imeshindikana.");
    }
  };

  const reject = async (r: ReqRow) => {
    await supabase.from("student_edit_requests" as any).update({
      status: "rejected",
      admin_notes: notes[r.id] || null,
      reviewed_at: new Date().toISOString(),
    }).eq("id", r.id);
    toast.info("Ombi limekataliwa.");
    await load();
  };

  const removeRow = async (r: ReqRow) => {
    if (!confirm("Futa ombi hili?")) return;
    await supabase.from("student_edit_requests" as any).delete().eq("id", r.id);
    await load();
  };

  const filtered = rows.filter((r) => filter === "all" ? true : r.status === filter);
  const pendingCount = rows.filter((r) => r.status === "pending").length;

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-5xl">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Admin
          </Link>
          <Button variant="outline" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5 mr-1" /> Sasisha</Button>
        </div>
        <h1 className="text-2xl font-extrabold mb-1 flex items-center gap-2">
          <Inbox className="h-6 w-6 text-accent" /> Maombi ya Marekebisho ya Matokeo
        </h1>
        <p className="text-sm text-muted-foreground mb-6">
          Wanafunzi waliokosewa jina au Reg No huleta maombi hapa. Ukiidhinisha, taarifa zinabadilika moja kwa moja kwenye matokeo, Excel, CSV na semina.
        </p>

        <Card className="p-4 mb-5 border-accent/30 shadow-card">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-accent" />
              <div>
                <Label className="text-sm font-bold">Ruhusu Wanafunzi Kuomba Marekebisho</Label>
                <p className="text-xs text-muted-foreground">Ukizima, fomu ya kuomba haitaonekana kwenye ukurasa wa matokeo.</p>
              </div>
            </div>
            <Switch checked={allowEdits} onCheckedChange={toggleAllow} />
          </div>
        </Card>

        <div className="flex gap-2 mb-4 flex-wrap">
          {(["pending","approved","rejected","all"] as const).map((f) => (
            <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)}>
              {f === "pending" ? `Yanasubiri (${pendingCount})` : f === "approved" ? "Yameidhinishwa" : f === "rejected" ? "Yamekataliwa" : "Yote"}
            </Button>
          ))}
        </div>

        {loading ? (
          <Card className="p-12 text-center text-muted-foreground">Inapakia…</Card>
        ) : filtered.length === 0 ? (
          <Card className="p-12 text-center text-muted-foreground">
            <Inbox className="h-10 w-10 mx-auto mb-2 opacity-40" />
            Hakuna maombi.
          </Card>
        ) : (
          <div className="space-y-3">
            {filtered.map((r) => (
              <Card key={r.id} className="p-5 shadow-card">
                <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Iliyowekwa kimakosa</div>
                    <div className="font-semibold">{r.current_full_name || r.submitted_full_name || "—"}</div>
                    <div className="font-mono-num text-xs text-muted-foreground">{r.current_reg_no || r.submitted_reg_no}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-widest text-accent">Inaombwa kuwa</div>
                    <div className="font-semibold text-accent">{r.requested_full_name}</div>
                    <div className="font-mono-num text-xs text-accent">{r.requested_reg_no}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Alama</div>
                    <div className="font-mono-num font-bold">
                      {r.score_snapshot != null ? `${r.score_snapshot}/${r.total_snapshot ?? "-"}` : "—"}
                    </div>
                    <span className={`inline-block mt-1 text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full ${
                      r.status === "pending" ? "bg-warning/15 text-warning" :
                      r.status === "approved" ? "bg-accent/15 text-accent" :
                      "bg-destructive/15 text-destructive"
                    }`}>{r.status}</span>
                  </div>
                </div>
                {r.reason && <p className="text-xs text-muted-foreground mb-2"><b>Sababu:</b> {r.reason}</p>}
                <p className="text-[11px] text-muted-foreground">Imewasilishwa: {new Date(r.created_at).toLocaleString()}</p>
                {r.status === "pending" && (
                  <div className="mt-3 space-y-2">
                    <Textarea
                      placeholder="Maelezo ya admin (hiari)"
                      value={notes[r.id] || ""}
                      onChange={(e) => setNotes({ ...notes, [r.id]: e.target.value })}
                      rows={2}
                      className="text-xs"
                    />
                    <div className="flex gap-2 flex-wrap">
                      <Button size="sm" onClick={() => approve(r)}>
                        <CheckCircle2 className="h-4 w-4 mr-1" /> Ridhia & Badilisha
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => reject(r)}>
                        <XCircle className="h-4 w-4 mr-1" /> Kataa
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => removeRow(r)} className="text-destructive">Futa</Button>
                    </div>
                  </div>
                )}
                {r.status !== "pending" && r.admin_notes && (
                  <p className="text-xs mt-2 italic text-muted-foreground">Admin: {r.admin_notes}</p>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminEditRequests;