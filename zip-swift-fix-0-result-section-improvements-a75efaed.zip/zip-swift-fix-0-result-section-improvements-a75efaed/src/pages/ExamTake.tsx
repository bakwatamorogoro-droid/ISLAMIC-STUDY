import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Clock, AlertTriangle, ChevronLeft, ChevronRight, ListChecks } from "lucide-react";
import { formatHMS, shuffle } from "@/lib/format";

interface Session { studentId: string; examId: string; fullName: string; examNumber: string; }
interface Question {
  id: string; question_text: string; question_type: "mcq" | "true_false" | "short_answer" | "long_answer";
  options: string[] | null; correct_answer: string; marks: number;
}

const ExamTake = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [exam, setExam] = useState<any>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [attemptId, setAttemptId] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [current, setCurrent] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [showReview, setShowReview] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const submittedRef = useRef(false);

  // ----- Load exam + questions + create attempt -----
  useEffect(() => {
    const s = sessionStorage.getItem("isStudyMum_student");
    if (!s) { navigate("/exam/register"); return; }
    const sess: Session = JSON.parse(s);
    setSession(sess);

    (async () => {
      const { data: examData } = await supabase.from("exams").select("*").eq("id", sess.examId).single();
      const { data: qs } = await supabase.from("questions").select("*").eq("exam_id", sess.examId).order("position");
      if (!examData || !qs) return;

      const ordered = examData.shuffle_questions ? shuffle(qs) : qs;
      setExam(examData);
      setQuestions(ordered as any);

      // create attempt
      const { data: attempt, error } = await supabase
        .from("attempts")
        .insert({
          student_id: sess.studentId,
          exam_id: sess.examId,
          status: "in_progress",
          total_marks: qs.reduce((sum, q: any) => sum + (q.marks || 1), 0),
          question_order: ordered.map((q: any) => q.id),
        })
        .select("id, started_at")
        .single();
      if (error) { toast.error(error.message); return; }
      setAttemptId(attempt.id);
      let initSecs = examData.duration_seconds;
      if (examData.scheduled_end_at) {
        const remain = Math.floor((new Date(examData.scheduled_end_at).getTime() - Date.now()) / 1000);
        if (remain > 0 && remain < initSecs) initSecs = remain;
        if (remain <= 0) initSecs = 1;
      }
      setSecondsLeft(initSecs);
    })();
  }, [navigate]);

  // ----- Auto-submit logic -----
  const submitExam = useCallback(async (status: "submitted" | "auto_submitted" | "terminated", reason?: string) => {
    if (submittedRef.current || !attemptId) return;
    submittedRef.current = true;
    setSubmitting(true);

    // Pre-build answer rows. Score MCQ immediately. Short answers go through AI for idea-based grading.
    let score = 0;
    let needsGrading = false;
    const answerRows: any[] = [];
    const shortIdx: { rowIndex: number; q: Question; ans: string }[] = [];

    questions.forEach((q) => {
      const ans = (answers[q.id] || "").trim();
      let isCorrect: boolean | null = null;
      let awarded: number | null = null;
      if (q.question_type === "mcq" || q.question_type === "true_false") {
        isCorrect = ans.toLowerCase() === q.correct_answer.trim().toLowerCase();
        if (isCorrect) score += q.marks;
      } else if (q.question_type === "short_answer") {
        // Will be filled by AI below
        isCorrect = null;
        awarded = null;
      } else {
        // long_answer — manual grading by admin
        needsGrading = true;
      }
      const idx = answerRows.length;
      answerRows.push({
        attempt_id: attemptId,
        question_id: q.id,
        answer_text: ans,
        is_correct: isCorrect,
        awarded_marks: awarded,
      });
      if (q.question_type === "short_answer") shortIdx.push({ rowIndex: idx, q, ans });
    });

    // Run AI grading for short_answer in parallel (fail-safe: if AI fails, fall back to exact match).
    if (shortIdx.length > 0) {
      const results = await Promise.all(
        shortIdx.map(async ({ q, ans }) => {
          try {
            const { data, error } = await supabase.functions.invoke("grade-short-answer", {
              body: {
                question: q.question_text,
                correctAnswer: q.correct_answer,
                studentAnswer: ans,
                marks: q.marks,
              },
            });
            if (error || !data || data.error) throw new Error("ai-fail");
            const aw = Math.max(0, Math.min(q.marks, Number(data.awarded) || 0));
            return { aw, correct: !!data.correct };
          } catch {
            // Fallback: exact-match
            const ok = ans && ans.toLowerCase() === q.correct_answer.trim().toLowerCase();
            return { aw: ok ? q.marks : 0, correct: !!ok };
          }
        }),
      );
      shortIdx.forEach((item, i) => {
        const { aw, correct } = results[i];
        answerRows[item.rowIndex].awarded_marks = aw;
        answerRows[item.rowIndex].is_correct = correct;
        score += aw;
      });
    }

    if (answerRows.length > 0) {
      await supabase.from("answers").insert(answerRows);
    }
    await supabase.from("attempts").update({
      status, score, needs_grading: needsGrading,
      submitted_at: new Date().toISOString(), violation_reason: reason || null,
    }).eq("id", attemptId);

    sessionStorage.setItem("isStudyMum_result", JSON.stringify({
      attemptId, score, total: questions.reduce((s, q) => s + q.marks, 0),
      status, reason, needsGrading,
    }));
    document.exitFullscreen?.().catch(() => {});
    navigate("/exam/result");
  }, [attemptId, answers, questions, navigate]);

  // ----- Timer (duration + hard deadline) -----
  useEffect(() => {
    if (!attemptId || secondsLeft <= 0) return;
    const t = setInterval(() => {
      // Hard deadline check
      if (exam?.scheduled_end_at) {
        const endMs = new Date(exam.scheduled_end_at).getTime();
        if (Date.now() >= endMs) {
          clearInterval(t);
          submitExam("auto_submitted", "Muda wa mwisho wa mtihani umefika");
          return;
        }
      }
      setSecondsLeft((s) => {
        if (s <= 1) { clearInterval(t); submitExam("auto_submitted", "Muda umeisha"); return 0; }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [attemptId, secondsLeft > 0, submitExam, exam?.scheduled_end_at]);

  // ----- Anti-cheat: enter fullscreen, watch visibility/blur/fullscreen-exit -----
  useEffect(() => {
    if (!attemptId) return;
    const root = document.documentElement;
    root.requestFullscreen?.().catch(() => {});

    // NOTE: Hatufanyi auto-submit mwanafunzi akipokea simu / akitoka kwenye tab kwa muda mfupi.
    // Tunaonya tu kwa fullscreen exit (siyo auto-submit).
    const block = (e: Event) => { e.preventDefault(); return false; };
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && ["c","v","x","p","s","u"].includes(e.key.toLowerCase())) e.preventDefault();
      if (e.key === "F12") e.preventDefault();
    };

    document.addEventListener("contextmenu", block);
    document.addEventListener("copy", block);
    document.addEventListener("paste", block);
    document.addEventListener("cut", block);
    document.addEventListener("keydown", onKey);

    return () => {
      document.removeEventListener("contextmenu", block);
      document.removeEventListener("copy", block);
      document.removeEventListener("paste", block);
      document.removeEventListener("cut", block);
      document.removeEventListener("keydown", onKey);
    };
  }, [attemptId, submitExam]);

  const answeredCount = useMemo(() => Object.values(answers).filter((v) => v && v.trim()).length, [answers]);

  if (!session || !exam || !attemptId) {
    return <div className="container py-20 text-center text-muted-foreground">Inaandaa mtihani...</div>;
  }
  if (questions.length === 0) {
    return <div className="container py-20 text-center text-muted-foreground">Mtihani huu hauna maswali.</div>;
  }

  const q = questions[current];
  const danger = secondsLeft <= 60;

  // ----- Review screen -----
  if (showReview) {
    return (
      <div className="min-h-screen bg-gradient-exam text-foreground select-none scene-3d">
        <Header secondsLeft={secondsLeft} danger={danger} title={exam.title} />
        <div className="container py-6 max-w-3xl">
          <h2 className="text-2xl font-extrabold mb-2 text-primary">Angalia Majibu Yako</h2>
          <p className="text-sm text-muted-foreground mb-6">Umejibu {answeredCount} kati ya {questions.length}. Bonyeza nambari kurudi kuhariri.</p>
          <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 gap-2 mb-8">
            {questions.map((qq, i) => {
              const ans = answers[qq.id]?.trim();
              return (
                <button key={qq.id} onClick={() => { setCurrent(i); setShowReview(false); }}
                  className={`h-10 rounded-lg text-sm font-semibold transition-smooth ${
                    ans ? "bg-accent text-white" : "bg-card text-foreground border border-border hover:bg-muted"
                  }`}>
                  {i + 1}
                </button>
              );
            })}
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="bg-card text-foreground border-border" onClick={() => setShowReview(false)}>Rudi kwenye Mtihani</Button>
            <Button className="flex-1 bg-accent hover:bg-accent/90 text-white"
              disabled={submitting} onClick={() => submitExam("submitted")}>
              {submitting ? "Inawasilisha..." : "Wasilisha Mtihani Sasa"}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-exam text-foreground select-none scene-3d">
      <Header secondsLeft={secondsLeft} danger={danger} title={exam.title} />

      <div className="container py-6 max-w-3xl">
        <div className="flex items-center justify-between mb-4 text-sm">
          <div className="text-muted-foreground">Swali <span className="font-bold text-primary">{current + 1}</span> / {questions.length}</div>
          <div className="text-muted-foreground">Alama: <span className="font-bold text-primary">{q.marks}</span></div>
        </div>

        <Card className="p-6 mb-4 shadow-card card-3d bg-card">
          <p className="text-lg font-semibold mb-5 text-foreground">{q.question_text}</p>

          {(q.question_type === "mcq" || q.question_type === "true_false") && (q.options || q.question_type === "true_false") && (
            <div className="space-y-2">
              {(q.options && q.options.length > 0 ? q.options : ["True", "False"]).map((opt, i) => {
                const letter = String.fromCharCode(65 + i);
                const selected = answers[q.id] === opt;
                return (
                  <button key={i} type="button"
                    onClick={() => setAnswers({ ...answers, [q.id]: opt })}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-smooth flex gap-3 items-start ${
                      selected ? "border-accent bg-accent/10 text-foreground" : "border-border hover:border-primary/30 bg-card text-foreground"
                    }`}>
                    <span className={`shrink-0 h-8 w-8 rounded-lg grid place-items-center font-bold text-sm ${
                      selected ? "bg-accent text-white" : "bg-muted text-muted-foreground"
                    }`}>{letter}</span>
                    <span className="pt-1 text-foreground">{opt}</span>
                  </button>
                );
              })}
            </div>
          )}

          {q.question_type === "short_answer" && (
            <Textarea
              value={answers[q.id] || ""}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder="Andika jibu lako fupi hapa..."
              rows={3}
              className="bg-white text-foreground border-border"
            />
          )}

          {q.question_type === "long_answer" && (
            <div>
              <Textarea
                value={answers[q.id] || ""}
                onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                placeholder="Andika jibu lako refu hapa (insha)..."
                rows={10}
                className="resize-y min-h-[200px] bg-white text-foreground border-border"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Maneno: <span className="font-mono-num font-bold text-foreground">{(answers[q.id] || "").trim().split(/\s+/).filter(Boolean).length}</span>
                {" · "}Hii itapimwa kwa mkono na admin.
              </p>
            </div>
          )}
        </Card>

        <div className="flex items-center gap-2">
          <Button variant="outline" className="bg-card text-foreground border-border" onClick={() => setCurrent((c) => Math.max(0, c - 1))} disabled={current === 0}>
            <ChevronLeft className="h-4 w-4 mr-1" /> Nyuma
          </Button>
          <Button variant="outline" className="bg-card text-foreground border-border" onClick={() => setShowReview(true)}>
            <ListChecks className="h-4 w-4 mr-1" /> Angalia Majibu
          </Button>
          {current < questions.length - 1 ? (
            <Button className="ml-auto bg-primary text-primary-foreground" onClick={() => setCurrent((c) => Math.min(questions.length - 1, c + 1))}>
              Mbele <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          ) : (
            <Button className="ml-auto bg-accent hover:bg-accent/90 text-white" onClick={() => setShowReview(true)}>
              Maliza <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

const Header = ({ secondsLeft, danger, title }: { secondsLeft: number; danger: boolean; title: string }) => (
  <header className="sticky top-0 z-40 bg-primary text-primary-foreground border-b border-primary/20 shadow-md">
    <div className="container h-16 flex items-center justify-between">
      <div className="flex items-center gap-3 min-w-0">
        <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
        <div className="font-extrabold truncate text-base md:text-xl text-white">{title}</div>
      </div>
      <div className={`flex items-center gap-2 px-4 py-2 rounded-xl font-mono-num font-bold text-lg ${
        danger ? "bg-destructive text-white animate-pulse" : "bg-white/20 text-white"
      }`}>
        {danger ? <AlertTriangle className="h-5 w-5" /> : <Clock className="h-5 w-5" />}
        {formatHMS(secondsLeft)}
      </div>
    </div>
  </header>
);

export default ExamTake;
