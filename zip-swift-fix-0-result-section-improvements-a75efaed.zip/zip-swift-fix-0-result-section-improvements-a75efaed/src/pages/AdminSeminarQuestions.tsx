import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { ArrowLeft, FileText, Upload, Loader2, Trash2, ExternalLink } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import { LanguageToggle } from "@/lib/i18n";

interface SQ {
  id: string; title: string; description: string | null; pdf_url: string;
  is_active: boolean; created_at: string;
}

const AdminSeminarQuestions = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<SQ[]>([]);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, []);

  const load = async () => {
    const { data } = await supabase.from("seminar_questions" as any).select("*").order("created_at", { ascending: false });
    setItems((data as any) || []);
  };

  const upload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return toast.error("Choose a PDF first");
    if (file.type !== "application/pdf") return toast.error("Must be a PDF");
    if (file.size > 20 * 1024 * 1024) return toast.error("PDF too large (max 20MB)");
    if (!title.trim()) return toast.error("Title required");
    setUploading(true);
    try {
      const path = `questions/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: upErr } = await supabase.storage.from("seminar-pdfs").upload(path, file, {
        contentType: "application/pdf", upsert: false,
      });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("seminar-pdfs").getPublicUrl(path);
      const { error } = await supabase.from("seminar_questions" as any).insert({
        title: title.trim(), description: desc.trim() || null, pdf_url: pub.publicUrl,
      });
      if (error) throw error;
      toast.success("Uploaded");
      setTitle(""); setDesc(""); setFile(null);
      if (fileRef.current) fileRef.current.value = "";
      load();
    } catch (e: any) {
      toast.error(e.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const toggleActive = async (sq: SQ) => {
    const { error } = await supabase.from("seminar_questions" as any).update({ is_active: !sq.is_active }).eq("id", sq.id);
    if (error) return toast.error(error.message);
    load();
  };

  const remove = async (sq: SQ) => {
    if (!confirm("Delete this question paper?")) return;
    const { error } = await supabase.from("seminar_questions" as any).delete().eq("id", sq.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    load();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="flex items-center justify-between mb-4">
          <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Admin
          </Link>
          <LanguageToggle />
        </div>
        <h1 className="text-2xl font-extrabold mb-1">Seminar Question Papers</h1>
        <p className="text-sm text-muted-foreground mb-6">Upload PDFs that will appear on the home page for students to download.</p>

        <Card className="p-6 mb-6 shadow-card">
          <form onSubmit={upload} className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="IS 114 Seminar Questions — Week 5" required />
            </div>
            <div>
              <Label>Description (optional)</Label>
              <Textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={2} />
            </div>
            <div>
              <Label>PDF File</Label>
              <Input ref={fileRef} type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files?.[0] || null)} required />
              {file && <p className="text-xs text-muted-foreground mt-1">📎 {file.name}</p>}
            </div>
            <Button type="submit" disabled={uploading || !file}>
              {uploading ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Uploading...</>) : (<><Upload className="h-4 w-4 mr-2" /> Upload</>)}
            </Button>
          </form>
        </Card>

        {items.length === 0 ? (
          <Card className="p-10 text-center text-muted-foreground">
            <FileText className="h-10 w-10 mx-auto mb-3 opacity-40" /> No question papers uploaded yet.
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {items.map((sq) => (
              <Card key={sq.id} className="p-5 shadow-card">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <h3 className="font-bold truncate">{sq.title}</h3>
                    {sq.description && <p className="text-xs text-muted-foreground line-clamp-2">{sq.description}</p>}
                    <p className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1">
                      {new Date(sq.created_at).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Switch checked={sq.is_active} onCheckedChange={() => toggleActive(sq)} />
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button asChild size="sm" variant="outline">
                    <a href={sq.pdf_url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3.5 w-3.5 mr-1" /> Open PDF
                    </a>
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(sq)} className="text-destructive hover:text-destructive">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminSeminarQuestions;
