import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Shield, ArrowLeft } from "lucide-react";
import { loginAdmin, verifyAdmin } from "@/lib/adminAuth";

const AdminLogin = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    verifyAdmin().then((a) => { if (a) navigate("/admin"); });
  }, [navigate]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await loginAdmin(username, password);
      toast.success("Karibu, Admin!");
      navigate("/admin");
    } catch (err: any) {
      toast.error(err.message || "Login imeshindwa");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8">
          <ArrowLeft className="h-4 w-4" /> Rudi nyumbani
        </Link>
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-hero items-center justify-center mb-4 text-primary-foreground shadow-elegant">
              <Shield className="h-7 w-7" />
            </div>
            <h1 className="text-3xl font-extrabold mb-2">Admin Login</h1>
            <p className="text-muted-foreground text-sm">Ingia kusimamia mitihani.</p>
          </div>
          <Card className="p-6 shadow-card">
            <form onSubmit={onSubmit} className="space-y-4">
              <div>
                <Label htmlFor="u">Username</Label>
                <Input id="u" value={username} onChange={(e) => setUsername(e.target.value)} required autoComplete="username" />
              </div>
              <div>
                <Label htmlFor="p">Password</Label>
                <Input id="p" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete="current-password" />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Inaingia..." : "Ingia"}
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
