import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { ArrowLeft, Megaphone, Plus, Trash2 } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";

interface Ann { id: string; title: string; body: string; is_active: boolean; created_at: string; }

const AdminAnnouncements = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<Ann[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [active, setActive] = useState(true);

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, [navigate]);

  const load = async () => {
    const { data } = await supabase.from("announcements" as any).select("*").order("created_at", { ascending: false });
    setItems((data as any) || []);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return toast.error("Jaza kichwa na maelezo");
    const { error } = await supabase.from("announcements" as any).insert({ title, body, is_active: active });
    if (error) return toast.error(error.message);
    toast.success("Tangazo limechapishwa");
    setTitle(""); setBody(""); setActive(true);
    load();
  };

  const toggle = async (a: Ann) => {
    await supabase.from("announcements" as any).update({ is_active: !a.is_active }).eq("id", a.id);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Futa tangazo hili?")) return;
    await supabase.from("announcements" as any).delete().eq("id", id);
    load();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-3xl">
        <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>
        <div className="flex items-center gap-3 mb-6">
          <Megaphone className="h-6 w-6 text-accent" />
          <h1 className="text-2xl font-extrabold">Matangazo</h1>
        </div>

        <Card className="p-6 mb-6 shadow-card">
          <h2 className="font-bold mb-4">Andika Tangazo Jipya</h2>
          <form onSubmit={save} className="space-y-3">
            <div>
              <Label>Kichwa</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Mfano: Mtihani wa Historia utaanza Jumanne" />
            </div>
            <div>
              <Label>Maelezo</Label>
              <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={4} placeholder="Andika ujumbe kwa wanafunzi..." />
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={active} onCheckedChange={setActive} id="ac" />
              <Label htmlFor="ac" className="cursor-pointer">Onyesha kwa wanafunzi</Label>
            </div>
            <Button type="submit"><Plus className="h-4 w-4 mr-1" /> Chapisha</Button>
          </form>
        </Card>

        <div className="space-y-3">
          {items.length === 0 && (
            <Card className="p-10 text-center text-muted-foreground">Hakuna matangazo bado.</Card>
          )}
          {items.map((a) => (
            <Card key={a.id} className="p-5 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold">{a.title}</h3>
                    <span className={`text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full ${a.is_active ? "bg-accent/10 text-accent" : "bg-muted text-muted-foreground"}`}>
                      {a.is_active ? "Live" : "Imezimwa"}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{a.body}</p>
                  <p className="text-xs text-muted-foreground mt-2">{new Date(a.created_at).toLocaleString()}</p>
                </div>
                <div className="flex flex-col gap-2 items-end">
                  <Switch checked={a.is_active} onCheckedChange={() => toggle(a)} />
                  <Button size="sm" variant="ghost" onClick={() => remove(a.id)} className="text-destructive hover:text-destructive">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminAnnouncements;
