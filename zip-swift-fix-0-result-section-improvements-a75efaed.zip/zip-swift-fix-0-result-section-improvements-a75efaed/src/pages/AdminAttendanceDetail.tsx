import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, FileDown, Users, Trash2 } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import { exportRowsToCSV } from "@/lib/exportResults";
import { toast } from "sonner";

const AdminAttendanceDetail = () => {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const [session, setSession] = useState<any>(null);
  const [records, setRecords] = useState<any[]>([]);

  useEffect(() => {
    verifyAdmin().then((a) => { if (!a) navigate("/admin/login"); else load(); });
  }, [sessionId]);

  const load = async () => {
    const { data: s } = await supabase.from("attendance_sessions" as any).select("*").eq("id", sessionId).single();
    setSession(s);
    const { data } = await supabase.from("attendance_records" as any)
      .select("*").eq("session_id", sessionId).order("confirmed_at", { ascending: true });
    setRecords((data as any) || []);
  };

  const exportCSV = () => {
    if (!records.length) return toast.info("Hakuna rekodi");
    exportRowsToCSV(
      `${(session?.title || "Attendance").replace(/\s+/g, "_")}_${session?.session_date}.csv`,
      ["#", "Reg No", "Jina", "Kozi", "Muda", "Distance (m)"],
      records.map((r, i) => [
        i + 1, r.reg_no, r.full_name, r.course || "",
        new Date(r.confirmed_at).toLocaleString(),
        r.distance_m != null ? Math.round(Number(r.distance_m)) : "",
      ]),
    );
  };

  const remove = async (id: string) => {
    if (!confirm("Futa rekodi hii?")) return;
    await supabase.from("attendance_records" as any).delete().eq("id", id);
    load();
  };

  if (!session) return null;

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/admin/attendance" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Vipindi
        </Link>
        <div className="flex items-start justify-between gap-3 flex-wrap mb-6">
          <div>
            <h1 className="text-2xl font-extrabold">{session.title}</h1>
            <p className="text-sm text-muted-foreground">📅 {session.session_date} — {records.length} waliothibitisha</p>
          </div>
          <Button onClick={exportCSV}><FileDown className="h-4 w-4 mr-1" /> Download CSV</Button>
        </div>

        {records.length === 0 ? (
          <Card className="p-12 text-center text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-40" />
            Hakuna mwanafunzi aliyethibitisha bado.
          </Card>
        ) : (
          <Card className="overflow-hidden shadow-card">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2 text-left">#</th>
                    <th className="px-3 py-2 text-left">Reg No</th>
                    <th className="px-3 py-2 text-left">Jina</th>
                    <th className="px-3 py-2 text-left">Kozi</th>
                    <th className="px-3 py-2 text-left">Muda</th>
                    <th className="px-3 py-2 text-right">Distance</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {records.map((r, i) => (
                    <tr key={r.id} className="hover:bg-muted/30">
                      <td className="px-3 py-2 font-mono-num">{i + 1}</td>
                      <td className="px-3 py-2 font-mono-num font-semibold">{r.reg_no}</td>
                      <td className="px-3 py-2">{r.full_name}</td>
                      <td className="px-3 py-2 text-muted-foreground">{r.course || "—"}</td>
                      <td className="px-3 py-2 text-xs text-muted-foreground">{new Date(r.confirmed_at).toLocaleString()}</td>
                      <td className="px-3 py-2 text-right font-mono-num">{r.distance_m != null ? Math.round(Number(r.distance_m)) : "—"}</td>
                      <td className="px-3 py-2 text-right">
                        <Button size="sm" variant="ghost" onClick={() => remove(r.id)} className="text-destructive">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminAttendanceDetail;
