import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertTriangle, Clock, Maximize, ShieldCheck, MapPin, Loader2 } from "lucide-react";
import { formatHMS } from "@/lib/format";
import { distanceMeters, getCurrentPosition } from "@/lib/geo";
import { toast } from "sonner";

interface Session { studentId: string; examId: string; fullName: string; examNumber: string; }

const ExamInstructions = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [exam, setExam] = useState<any>(null);
  const [agreed, setAgreed] = useState(false);
  const [checkingGeo, setCheckingGeo] = useState(false);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const s = sessionStorage.getItem("isStudyMum_student");
    if (!s) { navigate("/exam/register"); return; }
    const sess = JSON.parse(s);
    setSession(sess);
    supabase.from("exams").select("*").eq("id", sess.examId).single().then(({ data }) => setExam(data));
  }, [navigate]);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  if (!session || !exam) return <div className="container py-20 text-center text-muted-foreground">Inapakia...</div>;

  const startMs = exam.scheduled_start_at ? new Date(exam.scheduled_start_at).getTime() : null;
  const notYet = startMs !== null && now < startMs;
  const remainingMs = startMs ? Math.max(0, startMs - now) : 0;
  const fmtRemain = (ms: number) => {
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d}s ${pad(h)}:${pad(m)}:${pad(sec)}`;
  };

  const rules = [
    { icon: Maximize, text: "Mtihani lazima ufanyike katika hali ya FULL SCREEN." },
    { icon: ShieldCheck, text: "Copy, paste, na right-click vimezuiwa." },
    { icon: Clock, text: "Muda wa mtihani unaendelea hata ukifunga. Hakuna pause." },
    { icon: AlertTriangle, text: "Akaunti moja inaweza kufanya mtihani huu mara moja tu." },
    { icon: ShieldCheck, text: "✅ UKIPIGIWA SIMU au ukapokea simu wakati wa mtihani — mfumo HAUTAJISUBMIT wala HAUTAKUTOA. Endelea baada ya simu." },
    { icon: ShieldCheck, text: "✅ Tab-switch HAITAKUTOA kwenye mtihani. Endelea kazi yako bila wasiwasi." },
    ...(exam.scheduled_end_at ? [{
      icon: AlertTriangle,
      text: `⏰ Muda wa mwisho wa mtihani: ${new Date(exam.scheduled_end_at).toLocaleString()}. Ukifika muda huu na hujawasilisha, mfumo utawasilisha jibu lako otomatiki.`,
    }] : []),
    ...(exam.location_required ? [{
      icon: MapPin,
      text: `Lazima uwe ndani ya mita ${exam.location_radius_m || 200} kutoka eneo la mtihani. GPS itakaguliwa kabla ya kuanza.`,
    }] : []),
  ];

  const startExam = async () => {
    if (!exam.location_required) { navigate("/exam/take"); return; }
    setCheckingGeo(true);
    try {
      const pos = await getCurrentPosition();
      const dist = distanceMeters(pos.lat, pos.lng, exam.location_lat, exam.location_lng);
      if (dist > (exam.location_radius_m || 200)) {
        toast.error(`Uko mbali sana na eneo la mtihani (~${Math.round(dist)} m). Hauruhusiwi kuanza.`);
        setCheckingGeo(false);
        return;
      }
      toast.success(`Eneo limethibitishwa (~${Math.round(dist)} m)`);
      navigate("/exam/take");
    } catch (e: any) {
      toast.error(e.message || "Imeshindikana kupata eneo lako");
      setCheckingGeo(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-exam text-foreground scene-3d">
      <div className="container py-8 max-w-3xl">
        <div className="mb-8">
          <h1 className="text-3xl font-extrabold mb-1 text-primary">{exam.title}</h1>
          {exam.description && <p className="text-muted-foreground">{exam.description}</p>}
        </div>

        <Card className="p-6 mb-6 shadow-card bg-card card-3d">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div><div className="text-xs uppercase text-muted-foreground tracking-widest">Jina</div><div className="font-semibold text-foreground">{session.fullName}</div></div>
            <div><div className="text-xs uppercase text-muted-foreground tracking-widest">Namba</div><div className="font-mono-num font-semibold text-foreground">{session.examNumber}</div></div>
            <div><div className="text-xs uppercase text-muted-foreground tracking-widest">Muda</div><div className="font-mono-num font-semibold text-accent">{formatHMS(exam.duration_seconds)}</div></div>
            <div><div className="text-xs uppercase text-muted-foreground tracking-widest">Hali</div><div className="font-semibold text-accent">Tayari</div></div>
          </div>
        </Card>

        <Card className="p-6 mb-6 shadow-card bg-card card-3d">
          <h2 className="font-bold text-lg mb-4 flex items-center gap-2 text-foreground"><AlertTriangle className="h-5 w-5 text-warning" /> Sheria za Mtihani</h2>
          <ul className="space-y-3">
            {rules.map((r, i) => (
              <li key={i} className="flex gap-3">
                <div className="shrink-0 h-9 w-9 rounded-lg bg-primary/10 text-primary grid place-items-center">
                  <r.icon className="h-4 w-4" />
                </div>
                <p className="text-sm pt-2 text-foreground">{r.text}</p>
              </li>
            ))}
          </ul>
        </Card>

        <div className="flex items-center gap-3 mb-6">
          <Checkbox id="agree" checked={agreed} onCheckedChange={(c) => setAgreed(c === true)} />
          <label htmlFor="agree" className="text-sm cursor-pointer text-foreground">Nimesoma na nakubali sheria zote za mtihani.</label>
        </div>

        {notYet && (
          <Card className="p-5 mb-6 shadow-card border-warning/30 bg-warning/5">
            <div className="text-xs uppercase tracking-widest text-warning mb-1">Mtihani haujaanza</div>
            <div className="font-bold mb-1 text-foreground">Utaruhusiwa kuanza baada ya:</div>
            <div className="font-mono-num text-2xl text-accent">{fmtRemain(remainingMs)}</div>
            <div className="text-xs text-muted-foreground mt-1">
              Tarehe ya kuanza: {new Date(startMs!).toLocaleString()}
            </div>
          </Card>
        )}

        <div className="flex gap-3">
          <Button asChild variant="outline" className="bg-card text-foreground border-border"><Link to="/exam/register">Rudi</Link></Button>
          <Button className="flex-1 bg-primary text-primary-foreground" disabled={!agreed || checkingGeo || notYet} onClick={startExam}>
            {notYet ? "Subiri muda ufike..." : checkingGeo ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Inakagua eneo...</>) : "Anza Mtihani"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ExamInstructions;
