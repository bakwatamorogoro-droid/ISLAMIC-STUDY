import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft, Search, Edit3, Save, X, Users, AlertTriangle, CalendarClock, LogIn, RefreshCw, Trash2 } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";

interface Row {
  id: string;
  full_name: string;
  reg_no: string;
  mobile_no: string | null;
  gender: string | null;
  course: string | null;
  group_id: string;
  created_at: string;
  group_number?: number;
  group_title?: string | null;
  semester_id?: string;
  semester_title?: string;
}

const AdminSeminarBrowser = () => {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [eName, setEName] = useState("");
  const [eReg, setEReg] = useState("");

  // stats
  const [total, setTotal] = useState(0);
  const [todaySignups, setTodaySignups] = useState(0);
  const [todayLogins, setTodayLogins] = useState(0);
  const [duplicates, setDuplicates] = useState<Array<{ reg_no: string; count: number; names: string[] }>>([]);

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      loadStats();
    });
  }, []);

  const loadStats = async () => {
    const { count: tot } = await supabase.from("group_members").select("id", { count: "exact", head: true });
    setTotal(tot || 0);

    const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
    const iso = startOfDay.toISOString();

    const { count: ts } = await supabase
      .from("group_members")
      .select("id", { count: "exact", head: true })
      .gte("created_at", iso);
    setTodaySignups(ts || 0);

    // "logins" = wanafunzi waliingia kufanya mtihani leo (distinct students with attempt today)
    const { data: atts } = await supabase
      .from("attempts")
      .select("student_id, started_at")
      .gte("started_at", iso);
    const distinct = new Set((atts || []).map((a: any) => a.student_id));
    setTodayLogins(distinct.size);

    // duplicates: reg_no appearing more than once
    const all: Array<{ reg_no: string; full_name: string }> = [];
    let from = 0; const size = 1000;
    while (true) {
      const { data } = await supabase
        .from("group_members")
        .select("reg_no, full_name")
        .range(from, from + size - 1);
      const c = (data as any) || [];
      all.push(...c);
      if (c.length < size) break;
      from += size;
    }
    const map: Record<string, string[]> = {};
    all.forEach((m) => {
      const k = String(m.reg_no || "").toUpperCase().trim();
      if (!k) return;
      (map[k] ||= []).push(m.full_name);
    });
    const dups = Object.entries(map)
      .filter(([, v]) => v.length > 1)
      .map(([reg_no, names]) => ({ reg_no, count: names.length, names }))
      .sort((a, b) => b.count - a.count);
    setDuplicates(dups);
  };

  const search = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setLoading(true);
    try {
      let query = supabase
        .from("group_members")
        .select("id, full_name, reg_no, mobile_no, gender, course, group_id, created_at")
        .order("created_at", { ascending: false })
        .limit(200);
      const term = q.trim();
      if (term) query = query.or(`full_name.ilike.%${term}%,reg_no.ilike.%${term}%`);
      const { data: ms } = await query;
      const list = (ms as any[]) || [];
      // attach group + semester
      const groupIds = Array.from(new Set(list.map((m) => m.group_id)));
      let groupsMap: Record<string, any> = {};
      let semMap: Record<string, any> = {};
      if (groupIds.length) {
        const { data: gs } = await supabase
          .from("groups")
          .select("id, group_number, title, semester_id")
          .in("id", groupIds);
        (gs || []).forEach((g: any) => (groupsMap[g.id] = g));
        const semIds = Array.from(new Set((gs || []).map((g: any) => g.semester_id)));
        if (semIds.length) {
          const { data: ss } = await supabase.from("semesters").select("id, title").in("id", semIds);
          (ss || []).forEach((s: any) => (semMap[s.id] = s));
        }
      }
      const enriched: Row[] = list.map((m) => {
        const g = groupsMap[m.group_id] || {};
        const s = semMap[g.semester_id] || {};
        return {
          ...m,
          group_number: g.group_number,
          group_title: g.title,
          semester_id: g.semester_id,
          semester_title: s.title,
        };
      });
      setRows(enriched);
      if (enriched.length === 0) toast.info("Hakuna taarifa zilizopatikana.");
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (r: Row) => {
    setEditId(r.id); setEName(r.full_name); setEReg(r.reg_no);
  };

  const saveEdit = async (r: Row) => {
    const newName = eName.trim();
    const newReg = eReg.trim().toUpperCase();
    if (!newName || !newReg) return toast.error("Jaza majina yote na Reg No.");
    const oldReg = String(r.reg_no || "").toUpperCase().trim();
    const { error } = await supabase
      .from("group_members")
      .update({ full_name: newName, reg_no: newReg })
      .eq("id", r.id);
    if (error) return toast.error(error.message);
    if (oldReg && oldReg !== newReg) {
      await supabase
        .from("students")
        .update({ full_name: newName, exam_number: newReg })
        .ilike("exam_number", oldReg);
      await supabase
        .from("exam_marks" as any)
        .update({ reg_no: newReg, full_name: newName, updated_at: new Date().toISOString() })
        .ilike("reg_no", oldReg);
    } else {
      await supabase
        .from("students")
        .update({ full_name: newName })
        .ilike("exam_number", oldReg);
      await supabase
        .from("exam_marks" as any)
        .update({ full_name: newName, updated_at: new Date().toISOString() })
        .ilike("reg_no", oldReg);
    }
    toast.success("Taarifa zimerekebishwa kila sehemu.");
    setEditId(null);
    await search();
    await loadStats();
  };

  const deleteMember = async (r: Row) => {
    if (!confirm(`Futa usajili wa ${r.full_name} (${r.reg_no})? Hii haitafuta matokeo yake yaliyopo.`)) return;
    const { error } = await supabase.from("group_members").delete().eq("id", r.id);
    if (error) return toast.error(error.message);
    toast.success("Usajili umefutwa.");
    await search();
    await loadStats();
  };

  const deleteAllDuplicatesFor = async (regNo: string) => {
    if (!confirm(`Futa nakala zote zilizojirudia za Reg No ${regNo}? Itabaki rekodi MOJA tu (ya kwanza kujisajili).`)) return;
    const { data } = await supabase
      .from("group_members")
      .select("id, created_at")
      .ilike("reg_no", regNo)
      .order("created_at", { ascending: true });
    const list = (data as any[]) || [];
    if (list.length <= 1) { toast.info("Hakuna nakala za kufuta."); return; }
    const idsToDelete = list.slice(1).map((x) => x.id);
    const { error } = await supabase.from("group_members").delete().in("id", idsToDelete);
    if (error) return toast.error(error.message);
    toast.success(`Zimefutwa nakala ${idsToDelete.length}.`);
    await search();
    await loadStats();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="flex items-center justify-between mb-4">
          <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Admin
          </Link>
          <Button variant="outline" size="sm" onClick={loadStats}><RefreshCw className="h-3.5 w-3.5 mr-1" /> Sasisha</Button>
        </div>
        <h1 className="text-2xl font-extrabold mb-1">Seminar Browser</h1>
        <p className="text-sm text-muted-foreground mb-6">
          Tafuta, hariri na uone takwimu za wanafunzi wote waliojisajili kwenye semina.
        </p>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          <Card className="p-4">
            <div className="flex items-center gap-2 text-xs uppercase text-muted-foreground"><Users className="h-3.5 w-3.5" /> Jumla waliojisajili</div>
            <div className="text-3xl font-extrabold font-mono-num mt-1">{total}</div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-2 text-xs uppercase text-muted-foreground"><CalendarClock className="h-3.5 w-3.5" /> Wamejisajili leo</div>
            <div className="text-3xl font-extrabold font-mono-num mt-1">{todaySignups}</div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-2 text-xs uppercase text-muted-foreground"><LogIn className="h-3.5 w-3.5" /> Walioingia leo (mtihani)</div>
            <div className="text-3xl font-extrabold font-mono-num mt-1">{todayLogins}</div>
          </Card>
          <Card className="p-4 border-warning/40">
            <div className="flex items-center gap-2 text-xs uppercase text-warning"><AlertTriangle className="h-3.5 w-3.5" /> Waliojisajili zaidi ya mara moja</div>
            <div className="text-3xl font-extrabold font-mono-num mt-1">{duplicates.length}</div>
          </Card>
        </div>

        {duplicates.length > 0 && (
          <Card className="p-5 mb-6 border-warning/40 shadow-card">
            <h2 className="font-bold mb-3 flex items-center gap-2 text-warning">
              <AlertTriangle className="h-4 w-4" /> Reg No zilizojirudia
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="text-[10px] uppercase tracking-widest text-muted-foreground">
                  <tr><th className="text-left py-2">Reg No</th><th className="text-left">Idadi</th><th className="text-left">Majina</th><th className="text-right">Hatua</th></tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {duplicates.slice(0, 50).map((d) => (
                    <tr key={d.reg_no}>
                      <td className="py-1.5 font-mono-num">{d.reg_no}</td>
                      <td className="font-bold">{d.count}</td>
                      <td>{d.names.join(" • ")}</td>
                      <td className="text-right">
                        <Button size="sm" variant="destructive" onClick={() => deleteAllDuplicatesFor(d.reg_no)}>
                          <Trash2 className="h-3.5 w-3.5 mr-1" /> Futa nakala
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* Search */}
        <Card className="p-5 mb-4 shadow-card">
          <form onSubmit={search} className="flex gap-2 items-end flex-wrap">
            <div className="flex-1 min-w-[220px]">
              <Label>Tafuta (Reg No au Jina)</Label>
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="MUM2021-04-08738 au John" />
            </div>
            <Button type="submit" disabled={loading}>
              <Search className="h-4 w-4 mr-1" /> {loading ? "Inatafuta..." : "Tafuta"}
            </Button>
            <Button type="button" variant="outline" onClick={() => { setQ(""); search(); }}>Onyesha wote (200)</Button>
          </form>
        </Card>

        {rows.length > 0 && (
          <Card className="overflow-hidden shadow-card">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-2 py-3 text-left">Jina</th>
                    <th className="px-2 py-3 text-left">Reg No</th>
                    <th className="px-2 py-3 text-left">Semina</th>
                    <th className="px-2 py-3 text-left">Group</th>
                    <th className="px-2 py-3 text-left">Course</th>
                    <th className="px-2 py-3 text-left">Mobile</th>
                    <th className="px-2 py-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {rows.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/30">
                      <td className="px-2 py-2 font-semibold">
                        {editId === r.id ? <Input value={eName} onChange={(e) => setEName(e.target.value)} className="h-8" /> : r.full_name}
                      </td>
                      <td className="px-2 py-2 font-mono-num">
                        {editId === r.id ? <Input value={eReg} onChange={(e) => setEReg(e.target.value.toUpperCase())} className="h-8 font-mono-num" /> : r.reg_no}
                      </td>
                      <td className="px-2 py-2">{r.semester_title || "—"}</td>
                      <td className="px-2 py-2">Group {r.group_number ?? "—"}{r.group_title ? ` — ${r.group_title}` : ""}</td>
                      <td className="px-2 py-2">{r.course || "—"}</td>
                      <td className="px-2 py-2 font-mono-num">{r.mobile_no || "—"}</td>
                      <td className="px-2 py-2 text-right">
                        {editId === r.id ? (
                          <div className="flex gap-1 justify-end">
                            <Button size="sm" onClick={() => saveEdit(r)}><Save className="h-3.5 w-3.5 mr-1" /> Hifadhi</Button>
                            <Button size="sm" variant="ghost" onClick={() => setEditId(null)}><X className="h-3.5 w-3.5" /></Button>
                          </div>
                        ) : (
                          <div className="flex gap-1 justify-end">
                            <Button size="sm" variant="ghost" onClick={() => startEdit(r)}><Edit3 className="h-3.5 w-3.5 mr-1" /> Hariri</Button>
                            <Button size="sm" variant="ghost" onClick={() => deleteMember(r)} className="text-destructive hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></Button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminSeminarBrowser;
