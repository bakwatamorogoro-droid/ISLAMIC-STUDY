-- Endesha SQL hii kwenye Lovable Cloud (Supabase) > SQL Editor mara moja
-- ili kuwezesha vipengele vipya.

-- 1) Per-exam revision toggle
ALTER TABLE public.exams
  ADD COLUMN IF NOT EXISTS show_answers_after_submit boolean NOT NULL DEFAULT false;

-- 2) Optional gender on students
ALTER TABLE public.students
  ADD COLUMN IF NOT EXISTS gender text;

-- 3) Blocked students table
CREATE TABLE IF NOT EXISTS public.blocked_students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reg_no text NOT NULL UNIQUE,
  full_name text,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.blocked_students ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "blocked_students_read_all" ON public.blocked_students;
CREATE POLICY "blocked_students_read_all"
  ON public.blocked_students FOR SELECT USING (true);

DROP POLICY IF EXISTS "blocked_students_write_all" ON public.blocked_students;
CREATE POLICY "blocked_students_write_all"
  ON public.blocked_students FOR ALL USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS blocked_students_reg_no_idx
  ON public.blocked_students (lower(reg_no));

-- 4) Banner image kwenye home page (admin atapakia picha)
ALTER TABLE public.home_settings
  ADD COLUMN IF NOT EXISTS banner_image_url text;

-- 5) Storage bucket ya picha za banner (public read)
INSERT INTO storage.buckets (id, name, public)
VALUES ('banner-images', 'banner-images', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "banner_images_public_read" ON storage.objects;
CREATE POLICY "banner_images_public_read"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'banner-images');

DROP POLICY IF EXISTS "banner_images_public_write" ON storage.objects;
CREATE POLICY "banner_images_public_write"
  ON storage.objects FOR ALL
  USING (bucket_id = 'banner-images')
  WITH CHECK (bucket_id = 'banner-images');
