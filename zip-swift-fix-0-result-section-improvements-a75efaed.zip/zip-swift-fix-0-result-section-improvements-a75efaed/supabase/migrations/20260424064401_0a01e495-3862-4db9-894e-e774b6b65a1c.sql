
ALTER TABLE public.group_members
  ADD COLUMN IF NOT EXISTS gender text,
  ADD COLUMN IF NOT EXISTS course text,
  ADD COLUMN IF NOT EXISTS test1 numeric,
  ADD COLUMN IF NOT EXISTS test2 numeric,
  ADD COLUMN IF NOT EXISTS presentation numeric,
  ADD COLUMN IF NOT EXISTS contribution numeric,
  ADD COLUMN IF NOT EXISTS attendance numeric,
  ADD COLUMN IF NOT EXISTS quiz numeric,
  ADD COLUMN IF NOT EXISTS university_exam numeric;
