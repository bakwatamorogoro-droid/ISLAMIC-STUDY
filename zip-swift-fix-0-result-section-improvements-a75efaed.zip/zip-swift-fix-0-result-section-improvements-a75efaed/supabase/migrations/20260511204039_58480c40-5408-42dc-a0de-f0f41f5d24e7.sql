
-- ============ EXAMS / QUESTIONS / STUDENTS / ATTEMPTS / ANSWERS ============
CREATE TABLE public.exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  duration_seconds integer NOT NULL DEFAULT 1800,
  is_active boolean NOT NULL DEFAULT true,
  shuffle_questions boolean NOT NULL DEFAULT true,
  location_lat numeric,
  location_lng numeric,
  location_radius_m integer NOT NULL DEFAULT 200,
  location_required boolean NOT NULL DEFAULT false,
  scheduled_start_at timestamptz,
  scheduled_end_at timestamptz,
  results_published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  question_type text NOT NULL DEFAULT 'mcq',
  options jsonb,
  correct_answer text,
  marks integer NOT NULL DEFAULT 1,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX questions_exam_id_idx ON public.questions(exam_id);

CREATE TABLE public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_number text NOT NULL,
  full_name text NOT NULL,
  reg_no text,
  mobile_no text,
  course text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX students_exam_number_idx ON public.students(exam_number);

CREATE TABLE public.attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'in_progress',
  score integer NOT NULL DEFAULT 0,
  total_marks integer NOT NULL DEFAULT 0,
  question_order jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  submitted_at timestamptz,
  violation_reason text,
  needs_grading boolean NOT NULL DEFAULT false,
  auto_submitted boolean NOT NULL DEFAULT false,
  terminated boolean NOT NULL DEFAULT false,
  published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX attempts_exam_id_idx ON public.attempts(exam_id);
CREATE INDEX attempts_student_id_idx ON public.attempts(student_id);

CREATE TABLE public.answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id uuid NOT NULL REFERENCES public.attempts(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  answer_text text,
  short_answer text,
  long_answer text,
  is_correct boolean,
  awarded_marks integer,
  needs_grading boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX answers_attempt_id_idx ON public.answers(attempt_id);

CREATE TABLE public.exam_marks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid REFERENCES public.exams(id) ON DELETE CASCADE,
  reg_no text,
  full_name text,
  test1 numeric,
  test2 numeric,
  presentation numeric,
  contribution numeric,
  score numeric,
  max_score numeric,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX exam_marks_exam_id_idx ON public.exam_marks(exam_id);
CREATE INDEX exam_marks_reg_no_idx ON public.exam_marks(reg_no);

-- ============ ANNOUNCEMENTS & HOME SETTINGS ============
CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.home_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_title text DEFAULT '',
  hero_subtitle text DEFAULT '',
  empty_exams_message text DEFAULT '',
  system_locked boolean NOT NULL DEFAULT false,
  lock_message text DEFAULT '',
  admin_email text,
  admin_phone text,
  allow_student_edits boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ SEMESTERS / GROUPS / SEMINARS ============
CREATE TABLE public.semesters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  semester_id uuid REFERENCES public.semesters(id) ON DELETE CASCADE,
  group_number integer NOT NULL DEFAULT 1,
  title text,
  location_required boolean NOT NULL DEFAULT false,
  location_lat numeric,
  location_lng numeric,
  location_radius_m integer DEFAULT 200,
  student_limit integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX groups_semester_id_idx ON public.groups(semester_id);

CREATE TABLE public.group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  reg_no text NOT NULL,
  mobile_no text,
  gender text,
  course text,
  test1 numeric,
  test2 numeric,
  presentation numeric,
  contribution numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX group_members_group_id_idx ON public.group_members(group_id);
CREATE INDEX group_members_reg_no_idx ON public.group_members(reg_no);

CREATE TABLE public.seminar_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  pdf_url text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.group_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_name text,
  semester text,
  leader_name text,
  leader_phone text,
  pdf_url text,
  notes text,
  status text NOT NULL DEFAULT 'pending',
  admin_notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.student_edit_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid,
  current_full_name text,
  current_reg_no text,
  requested_full_name text,
  requested_reg_no text,
  submitted_full_name text,
  submitted_reg_no text,
  score_snapshot integer,
  total_snapshot integer,
  reason text,
  status text NOT NULL DEFAULT 'pending',
  admin_notes text,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ ATTENDANCE ============
CREATE TABLE public.attendance_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  session_date date NOT NULL DEFAULT CURRENT_DATE,
  notes text,
  is_open boolean NOT NULL DEFAULT true,
  location_lat numeric,
  location_lng numeric,
  location_radius_m integer DEFAULT 200,
  location_required boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.attendance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.attendance_sessions(id) ON DELETE CASCADE,
  reg_no text NOT NULL,
  full_name text,
  course text,
  distance_m numeric,
  confirmed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX attendance_records_session_idx ON public.attendance_records(session_id);

-- ============ ADMIN AUTH ============
CREATE TABLE public.admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.admin_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES public.admin_users(id) ON DELETE CASCADE,
  token text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 days'),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ DEFAULT DATA ============
-- Default admin: username "admin", password "admin123"
-- (bcrypt hash for "admin123")
INSERT INTO public.admin_users (username, password_hash)
VALUES ('admin', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy');

INSERT INTO public.home_settings (hero_title, hero_subtitle, empty_exams_message, lock_message)
VALUES (
  'IS STUDY MUM',
  'Mfumo wa kisasa wa mitihani mtandaoni',
  'Hakuna mtihani uliopangwa kwa sasa.',
  'Mfumo umefungwa kwa muda na admin. Tafadhali subiri.'
);

-- ============ ENABLE RLS ============
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_marks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.home_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.semesters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seminar_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_edit_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;

-- ============ RLS POLICIES ============
-- App tables: open access (the app uses publishable key without per-user auth;
-- admin write protection is enforced via the admin-auth edge function pattern).
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'exams','questions','students','attempts','answers','exam_marks',
    'announcements','home_settings','semesters','groups','group_members',
    'seminar_questions','group_submissions','student_edit_requests',
    'attendance_sessions','attendance_records'
  ]) LOOP
    EXECUTE format('CREATE POLICY "public read %1$s" ON public.%1$I FOR SELECT USING (true)', t);
    EXECUTE format('CREATE POLICY "public write %1$s" ON public.%1$I FOR INSERT WITH CHECK (true)', t);
    EXECUTE format('CREATE POLICY "public update %1$s" ON public.%1$I FOR UPDATE USING (true) WITH CHECK (true)', t);
    EXECUTE format('CREATE POLICY "public delete %1$s" ON public.%1$I FOR DELETE USING (true)', t);
  END LOOP;
END $$;

-- Admin tables: deny all direct access; only the edge function (service role) can read/write
-- (no policies = no access for anon/authenticated)

-- ============ STORAGE BUCKET FOR SUBMISSIONS ============
INSERT INTO storage.buckets (id, name, public) VALUES ('submissions', 'submissions', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "submissions public read" ON storage.objects
  FOR SELECT USING (bucket_id = 'submissions');
CREATE POLICY "submissions public upload" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'submissions');
