CREATE TABLE public.home_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hero_title text NOT NULL DEFAULT 'IS STUDY MUM',
  hero_subtitle text NOT NULL DEFAULT '',
  empty_exams_message text NOT NULL DEFAULT '',
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.home_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view home_settings" ON public.home_settings FOR SELECT USING (true);
CREATE POLICY "Anyone can insert home_settings" ON public.home_settings FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update home_settings" ON public.home_settings FOR UPDATE USING (true);

INSERT INTO public.home_settings (hero_title, hero_subtitle, empty_exams_message)
VALUES ('IS STUDY MUM', '', '');