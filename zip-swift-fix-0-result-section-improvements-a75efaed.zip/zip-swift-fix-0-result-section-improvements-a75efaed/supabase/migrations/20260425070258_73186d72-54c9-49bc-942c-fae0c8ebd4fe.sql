-- Add PDF attachment columns to groups
ALTER TABLE public.groups
  ADD COLUMN IF NOT EXISTS questions_pdf_url text,
  ADD COLUMN IF NOT EXISTS answers_pdf_url text;

-- Create public storage bucket for seminar PDFs
INSERT INTO storage.buckets (id, name, public)
VALUES ('seminar-pdfs', 'seminar-pdfs', true)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS policies (public read, open write — matches existing app auth model)
DROP POLICY IF EXISTS "Public can read seminar pdfs" ON storage.objects;
CREATE POLICY "Public can read seminar pdfs"
ON storage.objects FOR SELECT
USING (bucket_id = 'seminar-pdfs');

DROP POLICY IF EXISTS "Anyone can upload seminar pdfs" ON storage.objects;
CREATE POLICY "Anyone can upload seminar pdfs"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'seminar-pdfs');

DROP POLICY IF EXISTS "Anyone can update seminar pdfs" ON storage.objects;
CREATE POLICY "Anyone can update seminar pdfs"
ON storage.objects FOR UPDATE
USING (bucket_id = 'seminar-pdfs');

DROP POLICY IF EXISTS "Anyone can delete seminar pdfs" ON storage.objects;
CREATE POLICY "Anyone can delete seminar pdfs"
ON storage.objects FOR DELETE
USING (bucket_id = 'seminar-pdfs');