ALTER TABLE public.home_settings
  ADD COLUMN IF NOT EXISTS system_locked boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS lock_message text NOT NULL DEFAULT 'Mfumo umefungwa kwa muda na admin. Tafadhali subiri.',
  ADD COLUMN IF NOT EXISTS admin_email text,
  ADD COLUMN IF NOT EXISTS admin_phone text;