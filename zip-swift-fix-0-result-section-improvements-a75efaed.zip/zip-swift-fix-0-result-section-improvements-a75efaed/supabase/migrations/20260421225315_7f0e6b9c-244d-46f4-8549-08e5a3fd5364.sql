-- Allow admin to publish results per exam
ALTER TABLE public.exams ADD COLUMN IF NOT EXISTS results_published boolean NOT NULL DEFAULT false;

-- Manual grading support for long-answer questions
ALTER TABLE public.answers ADD COLUMN IF NOT EXISTS awarded_marks numeric DEFAULT NULL;

-- Track attempts that still need manual grading
ALTER TABLE public.attempts ADD COLUMN IF NOT EXISTS needs_grading boolean NOT NULL DEFAULT false;