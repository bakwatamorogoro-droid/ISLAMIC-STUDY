
-- Allow public write on exams (admin gated in app)
CREATE POLICY "Anyone can insert exams" ON public.exams FOR INSERT TO public WITH CHECK (true);
CREATE POLICY "Anyone can update exams" ON public.exams FOR UPDATE TO public USING (true);
CREATE POLICY "Anyone can delete exams" ON public.exams FOR DELETE TO public USING (true);
CREATE POLICY "Anyone can view all exams" ON public.exams FOR SELECT TO public USING (true);

-- Allow public write on questions
CREATE POLICY "Anyone can insert questions" ON public.questions FOR INSERT TO public WITH CHECK (true);
CREATE POLICY "Anyone can update questions" ON public.questions FOR UPDATE TO public USING (true);
CREATE POLICY "Anyone can delete questions" ON public.questions FOR DELETE TO public USING (true);

-- Allow admin table reads (used by edge function with service role anyway, but safe)
-- (Intentionally no public policies on admins table)

-- Add geolocation columns to exams
ALTER TABLE public.exams
  ADD COLUMN IF NOT EXISTS location_lat double precision,
  ADD COLUMN IF NOT EXISTS location_lng double precision,
  ADD COLUMN IF NOT EXISTS location_radius_m integer NOT NULL DEFAULT 200,
  ADD COLUMN IF NOT EXISTS location_required boolean NOT NULL DEFAULT false;
